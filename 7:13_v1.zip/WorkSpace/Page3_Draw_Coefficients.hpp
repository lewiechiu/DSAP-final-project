
#ifndef Page3_Draw_Coefficients_hpp
#define Page3_Draw_Coefficients_hpp

#include <stdio.h>
extern float thickness;
//Buttons for bar and pie switcher
extern float Button_x_Start, Button_x_End, Button_y_Start, Button_y_End ;
extern float Button_x_Gap, Button_y_Gap;
//Week
extern float Bar_Week_Pos_X_Start,Bar_Week_Pos_X_End, Bar_Week_Pos_X_Gap, Bar_Week_Pos_Y;
//Month
extern float Bar_Month_Pos_X_Start,Bar_Month_Pos_X_End, Bar_Month_Pos_X_Gap, Bar_Month_Pos_Y;
//Year
extern float Bar_Year_Pos_X_Start,Bar_Year_Pos_X_End, Bar_Year_Pos_X_Gap, Bar_Year_Pos_Y;

//Color
//Week
extern float Bar_Week_Red_Start, Bar_Week_Green_Start, Bar_Week_Blue_Start;
extern float
Bar_Week_Red_Gap,
Bar_Week_Green_Gap,
Bar_Week_Blue_Gap;
//Month
extern float Bar_Month_Red_Start, Bar_Month_Green_Start, Bar_Month_Blue_Start;
extern float
Bar_Month_Red_Gap,
Bar_Month_Green_Gap,
Bar_Month_Blue_Gap;
//Year
extern float Bar_Year_Red_Start, Bar_Year_Green_Start, Bar_Year_Blue_Start;
extern float
Bar_Year_Red_Gap,
Bar_Year_Green_Gap,
Bar_Year_Blue_Gap;



#endif /* Page3_Draw_Coefficients_hpp */
