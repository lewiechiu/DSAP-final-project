#define SELBAWARD_NO_NAMESPACE_SHORTCUT before including any Selba Ward
#include "SelbaWard/PieChart.hpp"
#include "SelbaWard/PieChart.cpp"
#include "SelbaWard/Line.hpp"
#include "SelbaWard/Line.cpp"
#include <iostream>
#include <string>
#include <time.h>
#include "OurTime.hpp"
#include "mission.h"
#include "FixedEvent.h"

#include <sstream>
#include <SFML/Graphics.hpp>
#include "LinkedBag.h"
#include "Knapscak.h"
#include <fstream>
#include <math.h>
#include "Bags&List.hpp"
#include "Day.hpp"
#include "Page3_Draw_Coefficients.hpp"

#define weeks 78
#define aweek 7

using namespace std;

/*------------------------------------------------------PAGE 2-------------------------------------------------------------------*/
OurTime NOW;

float toPx(float cm);
float inCM(float length);
float inPT(float length);
float font_resize(int oriSize);

int OutTimeHM2Int(OurTime& T);
OurTime CountDate(OurTime& TIME, int Gap);
int round(int MinuGap);
void DrawCalenderBox(sf::RenderWindow& wn, sf::RectangleShape* ALL_RECTAN, const MissionBag& MBag, const FixedEventBag& FEBag, int move=0);
//move: -1 ->past week
//move: +1 ->next week
int MouseOnBoxes(sf::RenderWindow& wn, sf::RectangleShape* RS, int total);
int MouseOnTurnPage(sf::RenderWindow& wn, sf::CircleShape& leftButton, sf::CircleShape& rightButton);
void DrawBoxMes(sf::RenderWindow& wn, sf::RectangleShape* RS,sf::RectangleShape* BoxMes_Button, const MissionBag& MBag, const FixedEventBag& FEBag, int index);
int TotalBoxes;
int BoxIndex;
bool DisplayBox= false;
sf::Font font;
int BoxMes_Button_index;
const float Remove_Button_XLen = toPx(1.88);
const float Remove_Button_YLen = toPx(0.5);
float Remove_Button_X;
float Remove_Button_Y;
const float Check_Button_XLen = toPx(1.88);
const float Check_Button_YLen = toPx(0.5);
float Check_Button_X;
float Check_Button_Y;
float X_Metrix[7];
float X_Start;
float Y_Start;
float Y_Length;
const float X_Length = inCM(3.24);
const float Y_Origin = inCM(3.77);
const float Y_Width_perMin = inCM(3.53)/360;
/*------------------------------------------------------PAGE 2-------------------------------------------------------------------*/




/*------------------------------------------------------PAGE 3-------------------------------------------------------------------*/
float Pge3_toPx(float cm);

static const string  y ="Y";
static const string  w = "W";
static const string  m = "M";
static const string  d = "D";
//SIDE FUNCTIONS
void Choose_Color(float& Red, float& Green, float& Blue, string& Scale);

//DETECT THE MOUSE
bool MouseOnBar(sf::RenderWindow& wn, const string& Scale);
bool MouseOnPie(sf::RenderWindow& wn);
bool MouseOnBarSW(sf::RenderWindow& wn);
bool MouseOnPieSW(sf::RenderWindow& wn);
bool MouseOnPieScale(sf::RenderWindow& wn, const string& Scale);
bool MouseOnLBarSW(sf::RenderWindow& wn, const string& Scale);

//CHECK THE TIME SCALE
bool isThisWeek(Event* Mission);
bool isThisMonth(Event* Mission);
bool isThisYear(Event* Mission);
bool isPast7Days(Event* Mission);
bool isPast4Weeks(Event* Mission);

//DETERMINE THE TIME OF MISSIONS
int getWhichDay(Event* Mission);
//Return from 0 to 6, return -1 if error
//Used by DrawRBar, n indicates the mission is past (n+1) day, respective to now.
int getWhichWeek(Event* Mission);
//Return from 0 to 4, return -1 if error
//Used by DrawRBar, n indicates the mission is past (n+1) week, respective to now.

//DRAW
void DrawStatic(sf::RenderWindow& wn, int ChartType, string& RBar_Scale);
void DrawRBar(sf::RenderWindow& wn, MissionBag& MBag, string& Scale);
//Scale: "W": week; "D": day
void DrawPie(sf::RenderWindow& wn, List& lis, int Amount, string& Scale, bool explode);
//lis: Descending sorted list
//Scale: "W": week; "M": month; "Y": Year
void DrawBar(sf::RenderWindow& wn, List& lis, int Amount, const string& Scale);
//Ratio: Descending sorted list
//Scale: "W": week; "M": month; "Y": Year
void DrawBarTitle(sf::RenderWindow& wn);

//MESSEGE WINDOWS
void ShowBarMes(sf::RenderWindow& wn, List& lis, const string& Scale);
void ShowPieMes(sf::RenderWindow& wn, List& lis, const string& Scale);

/*------------------------------------------------------PAGE 3-------------------------------------------------------------------*/


int main()
{
    //----------------------------------------------------------page 3
    bool page3 = false;
    string Pie_scale = "W";
    string RBar_scale = "W";
    int Bar2PieSW = 0;//0: Bar, 1: Pie
    
    //page 2 Initialized Variables
    
    for(int i=0; i<7; i++)
        X_Metrix[i] = inCM(7.36 + 3.24 * i);
    font.loadFromFile("Calibri.ttf");
    int oper;
    FixedEventBag FEBag;
    MissionBag MBag;
    MissionBag Done;
    OurTime today;
    OurTime start("201807080000");
    today.Current();
    today.setHour(0);
    today.setMinute(0);
    Day *year2018[weeks][aweek];
    Day *week[7];


    string MissionLocation = "Mission.txt";
    string FixedLocation = "FixedEvent.txt";
    MBag.LoadFile(MissionLocation);
    FEBag.LoadFile(FixedLocation);


    //draw window
    sf::RenderWindow window(sf::VideoMode(1600, 900), "My Schedule Assistant", sf::Style::Titlebar | sf::Style::Close);
    string userpassword = "123456";

    //draw clock
    sf::CircleShape shapeOut(toPx(4.25), 100);
    shapeOut.setFillColor(sf::Color(86, 175, 191));
    shapeOut.setPosition(toPx(-4.25), toPx(3.69 - 1.5));
    sf::CircleShape shape(toPx(3), 100);
    shape.setFillColor(sf::Color(0,0,0));
    shape.setPosition(toPx(-3), toPx(4.95 - 1.5));
    shape.setOutlineThickness(toPx(0.25));
    shape.setOutlineColor(sf::Color(162, 219, 214));
    sf::RectangleShape line_hour(sf::Vector2f(toPx(2), toPx(0.1)));
    line_hour.setPosition(toPx(0.05),toPx(5.9 - 1.5));
    line_hour.setFillColor(sf::Color(86, 175, 191));
    line_hour.rotate(90);
    sf::RectangleShape line_minute(sf::Vector2f(toPx(2.5), toPx(0.05)));
    line_minute.setPosition(toPx(0.05), toPx(7.9 - 1.5));
    line_minute.setFillColor(sf::Color(86, 175, 191));
    line_minute.rotate(40);
    sf::CircleShape center(toPx(0.15), 100);
    center.setFillColor(sf::Color(86, 175, 191));
    center.setPosition(toPx(-0.15), toPx(7.79 - 1.5));

    //draw login bar
    sf::RectangleShape downRectangle(sf::Vector2f(toPx(33.87), toPx(1.79)));
    sf::Texture texture1;
    if(!texture1.loadFromFile("transparent.png"))
    {
        cout << "texture1 wrong";
    }
    texture1.loadFromFile("transparent.png");
    downRectangle.setTexture(&texture1);

    //draw text
    sf::Font font;
    if(!font.loadFromFile("calibri.ttf"))
    {
        cout << "font wrong";
    }
    sf::Text text;
    text.setFont(font);
    text.setString("My");
    text.setFillColor(sf::Color(255, 255, 255));
    text.setCharacterSize(font_resize(60));
    text.setPosition(toPx(5.81), toPx(4 - 1.5));
    text.setStyle(sf::Text::Bold);

    sf::Text text2;
    text2.setFont(font);
    text2.setString("Schedule");
    text2.setFillColor(sf::Color(255, 255, 255));
    text2.setCharacterSize(font_resize(60));
    text2.setPosition(toPx(5.81), toPx(6.5 - 1.5));
    text2.setStyle(sf::Text::Bold);

    sf::Text text3;
    text3.setFont(font);
    text3.setString("Assistant");
    text3.setFillColor(sf::Color(255, 255, 255));
    text3.setCharacterSize(font_resize(60));
    text3.setPosition(toPx(5.81), toPx(9 - 1.5));
    text3.setStyle(sf::Text::Bold);

    sf::Text loginIntroduction;
    loginIntroduction.setFont(font);
    loginIntroduction.setString("[ please enter your password ] ");
    loginIntroduction.setCharacterSize(font_resize(20));
    loginIntroduction.setFillColor(sf::Color(255, 255, 255, 100));


    sf::String password;
    string passwordStr;
    sf::Text userText;
    userText.setFont(font);
    userText.setCharacterSize(font_resize(20));
    userText.setFillColor(sf::Color::White);
    bool passwordCorrect = false;

//----------------------------------------------------------page 2
    bool page2 = false;


    //font
    sf::Font calibri_normal;
    calibri_normal.loadFromFile("calibri.ttf");
    sf::Font calibri_italic;
    calibri_italic.loadFromFile("calibrii.ttf");
    sf::Font calibri_bold;
    calibri_bold.loadFromFile("calibrib.ttf");

    //Schedule button
    sf::RectangleShape scheduleButton(sf::Vector2f(inCM(1.5), inCM(9.5)));
    scheduleButton.setFillColor(sf::Color(86, 175, 191));
    scheduleButton.setPosition(0, 0);
    sf::Text scheduleText;
    scheduleText.setFont(calibri_normal);
    scheduleText.setPosition(inCM(0.6), inCM(1.5));
    scheduleText.setString("S\nC\nH\nE\nD\nU\nL\nE");
    scheduleText.setCharacterSize(font_resize(18));
    scheduleText.setFillColor(sf::Color(255, 255, 255));
    //Dashboard button
    sf::RectangleShape dashboardButton(sf::Vector2f(inCM(1.5), inCM(9.5)));
    dashboardButton.setFillColor(sf::Color(11, 83, 149));
    dashboardButton.setPosition(inCM(0), inCM(9.53));
    sf::Text dashboardText;
    dashboardText.setFont(calibri_normal);
    dashboardText.setPosition(inCM(0.6), inCM(1.5 + 9.5));
    dashboardText.setString("D\nA\nS\nH\nB\nO\nA\nR\nD");
    dashboardText.setCharacterSize(font_resize(18));
    scheduleText.setFillColor(sf::Color(255, 255, 255));
    //Add button
    sf::CircleShape addButton(inCM(0.75), 100);
    addButton.setPosition(0, inCM(9.5 - 0.75));
    addButton.setFillColor(sf::Color(255, 255, 255));
    sf::RectangleShape h_plus(sf::Vector2f(inCM(0.6), inCM(0.1)));
    h_plus.setFillColor(sf::Color(62, 149, 164));
    h_plus.setPosition(inCM(1.5 / 2 - 0.6 / 2), inCM(9.5 - 0.1 / 2));
    sf::RectangleShape v_plus(sf::Vector2f(inCM(0.1), inCM(0.6)));
    v_plus.setFillColor(sf::Color(62, 149, 164));
    v_plus.setPosition(inCM(1.5 / 2 - 0.1 / 2), inCM(9.5 - 0.6 / 2));


    //Vertical lines
    sf::RectangleShape v_linePtr[8];
    for(int i = 0; i < 8; i++)
    {
        v_linePtr[i].setSize(sf::Vector2f(inPT(0.5), inCM(15)));
        v_linePtr[i].setFillColor(sf::Color(65, 154, 169));
        v_linePtr[i].setPosition(inCM(7.36 + 3.24 * i), inCM(2.76));
    }
    //horizontal lines
    sf::RectangleShape h_linePtr[5];
    for(int i = 0; i < 5; i++)
    {
        h_linePtr[i].setSize(sf::Vector2f(inCM(23), inPT(0.6)));
        h_linePtr[i].setFillColor(sf::Color(166, 166, 166));
        h_linePtr[i].setPosition(inCM(7.05), inCM(3.77 + 3.51 * i));
    }

    //Time
    sf::Text time[5];
    for(int i = 0; i < 5; i++)
    {
        time[i].setFont(calibri_normal);
        time[i].setCharacterSize(font_resize(14));
        time[i].setFillColor(sf::Color(166, 166, 166));
        time[i].setPosition(inCM(5.42), inCM(3.45 + 3.5 * i));
        if(i < 2)
            time[i].setString(std::string("0" + std::to_string(0 + 6 * i) + ":00"));
        else
            time[i].setString(std::string(std::to_string(0 + 6 * i) + ":00"));
    }

    //Left page button
    sf::CircleShape leftButton(inCM(0.5 / 2), 3);
    leftButton.setFillColor(sf::Color(86, 175, 191));
    leftButton.setPosition(inCM(2.72), inCM(9.28));
    leftButton.rotate(30);
    //Right page button
    sf::CircleShape rightButton(inCM(0.5 / 2), 3);
    rightButton.setFillColor(sf::Color(86, 175, 191));
    rightButton.setPosition(inCM(32.13), inCM(9.28));
    rightButton.rotate(-30);

    //black filter
    bool filterOn = false;
    sf::RectangleShape filter(sf::Vector2f(1600 - inCM(1.5), 900));
    filter.setFillColor(sf::Color(0, 0, 0, 180));
    filter.setPosition(inCM(1.5), 0);

    //Select Event Menu//////////////////////////////////////////////////////////////////////////////////
    bool selectEventMenuOn = false;
    sf::RectangleShape selectEventMenu(sf::Vector2f(inCM(9), inCM(10)));
    selectEventMenu.setFillColor(sf::Color(255, 255, 255));
    selectEventMenu.setPosition(800 - inCM(9) / 2 + inCM(1.5), 450 - inCM(10) / 2);
    //Select Event Menu Title
    sf::Text selectEventMenuTitle;
    selectEventMenuTitle.setString("Select Event Type");
    selectEventMenuTitle.setCharacterSize(font_resize(20));
    selectEventMenuTitle.setFont(calibri_bold);
    selectEventMenuTitle.setFillColor(sf::Color(62, 149, 164));
    selectEventMenuTitle.setPosition(selectEventMenu.getPosition().x + selectEventMenu.getSize().x / 2 - selectEventMenuTitle.getLocalBounds().width / 2, selectEventMenu.getPosition().y + inCM(1.45));
    //flexible time mission button
    sf::RectangleShape FMbutton(sf::Vector2f(inCM(7), inCM(1)));
    FMbutton.setFillColor(sf::Color(162, 219, 214));
    FMbutton.setPosition(selectEventMenu.getPosition().x + selectEventMenu.getSize().x / 2 - FMbutton.getSize().x / 2, selectEventMenu.getPosition().y + inCM(3));
    sf::Text FMbuttonText;
    FMbuttonText.setString("Flexible Time Mission");
    FMbuttonText.setCharacterSize(font_resize(18));
    FMbuttonText.setFont(calibri_normal);
    FMbuttonText.setFillColor(sf::Color(62, 149, 164));
    FMbuttonText.setPosition(FMbutton.getPosition().x + FMbutton.getSize().x / 2 - FMbuttonText.getLocalBounds().width / 2, FMbutton.getPosition().y + inCM(0.1));
    //fixed time event button
    sf::RectangleShape FEbutton(sf::Vector2f(inCM(7), inCM(1)));
    FEbutton.setFillColor(sf::Color(162, 219, 214));
    FEbutton.setPosition(selectEventMenu.getPosition().x + selectEventMenu.getSize().x / 2 - FEbutton.getSize().x / 2, FMbutton.getPosition().y + inCM(2.25));
    sf::Text FEbuttonText;
    FEbuttonText.setString("Fixed Time Event");
    FEbuttonText.setCharacterSize(font_resize(18));
    FEbuttonText.setFont(calibri_normal);
    FEbuttonText.setFillColor(sf::Color(62, 149, 164));
    FEbuttonText.setPosition(FEbutton.getPosition().x + FEbutton.getSize().x / 2 - FEbuttonText.getLocalBounds().width / 2, FEbutton.getPosition().y + inCM(0.1));
    //cancel button
    sf::RectangleShape cancelButton(sf::Vector2f(inCM(3), inCM(1)));
    cancelButton.setFillColor(sf::Color(162, 219, 214));
    cancelButton.setPosition(selectEventMenu.getPosition().x + selectEventMenu.getSize().x / 2 - cancelButton.getSize().x / 2, FEbutton.getPosition().y + inCM(2.25));
    sf::Text cancelButtonText;
    cancelButtonText.setString("cancel");
    cancelButtonText.setCharacterSize(font_resize(18));
    cancelButtonText.setFont(calibri_normal);
    cancelButtonText.setFillColor(sf::Color(62, 149, 164));
    cancelButtonText.setPosition(cancelButton.getPosition().x + cancelButton.getSize().x / 2 - cancelButtonText.getLocalBounds().width / 2, cancelButton.getPosition().y + inCM(0.1));

    //add flexible time mission menu////////////////////////////////////////////////////////////////////////
    bool FMmenuOn = false;
    sf::RectangleShape FMmenu(sf::Vector2f(inCM(12), inCM(18)));
    FMmenu.setFillColor(sf::Color(255, 255, 255, 243));
    FMmenu.setPosition(800 - inCM(12) / 2 + inCM(1.5), 450 - inCM(18) / 2);
    //add flexible time mission title
    sf::Text FMmenuTitle;
    FMmenuTitle.setString("Add Flexible Time Mission");
    FMmenuTitle.setFont(calibri_bold);
    FMmenuTitle.setCharacterSize(font_resize(20));
    FMmenuTitle.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - FMmenuTitle.getLocalBounds().width / 2, FMmenu.getPosition().y + inCM(1.2));
    FMmenuTitle.setFillColor(sf::Color(62, 149, 164));
    //mission name text
    sf::Text missionNameText;
    missionNameText.setString("Mission Name");
    missionNameText.setFont(calibri_italic);
    missionNameText.setCharacterSize(font_resize(18));
    missionNameText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - missionNameText.getLocalBounds().width / 2, FMmenu.getPosition().y + inCM(2.6));
    missionNameText.setFillColor(sf::Color(62, 149, 164));
    //mission name block
    bool missionNameBlockOn = false;
    sf::RectangleShape missionNameBlock(sf::Vector2f(inCM(6), inCM(1)));
    missionNameBlock.setFillColor(sf::Color(217, 217, 217));
    missionNameBlock.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - missionNameBlock.getSize().x / 2, FMmenu.getPosition().y + inCM(3.6));
    //mission name typed
    std::string missionName = "";
    sf::Text missionNameTyped;
    missionNameTyped.setString(missionName);
    missionNameTyped.setFont(calibri_normal);
    missionNameTyped.setCharacterSize(font_resize(15));
    missionNameTyped.setFillColor(sf::Color(100, 100, 100));
    missionNameTyped.setPosition(missionNameBlock.getPosition() + sf::Vector2f(inCM(0.5), inCM(0.1)));
    //category text
    sf::Text categoryText;
    categoryText.setString("Category");
    categoryText.setFont(calibri_italic);
    categoryText.setCharacterSize(font_resize(18));
    categoryText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - categoryText.getLocalBounds().width / 2, missionNameText.getPosition().y + inCM(2.22));
    categoryText.setFillColor(sf::Color(62, 149, 164));
    //category block
    bool categoryBlockOn = false;
    sf::RectangleShape categoryBlock(sf::Vector2f(inCM(6), inCM(1)));
    categoryBlock.setFillColor(sf::Color(217, 217, 217));
    categoryBlock.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - categoryBlock.getSize().x / 2, missionNameBlock.getPosition().y + inCM(2.22));
    //category typed
    std::string FMcategory = "";
    sf::Text FMcategoryTyped;
    FMcategoryTyped.setString(FMcategory);
    FMcategoryTyped.setFont(calibri_normal);
    FMcategoryTyped.setCharacterSize(font_resize(15));
    FMcategoryTyped.setFillColor(sf::Color(100, 100, 100));
    FMcategoryTyped.setPosition(categoryBlock.getPosition() + sf::Vector2f(inCM(0.5), inCM(0.1)));
    //deadline text
    sf::Text deadlineText;
    deadlineText.setString("Deadline");
    deadlineText.setFont(calibri_italic);
    deadlineText.setCharacterSize(font_resize(18));
    deadlineText.setFillColor(sf::Color(62, 149, 164));
    deadlineText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - deadlineText.getLocalBounds().width / 2, categoryText.getPosition().y + inCM(2.22));
    //deadline block
    bool deadlineBlockOn[5];
    for(int i = 0; i < 5; i++)
        deadlineBlockOn[i] = false;
    sf::RectangleShape deadlineBlock[5];
    for(int i = 0; i < 5; i++)
    {
        deadlineBlock[i].setSize(sf::Vector2f(inCM(1.15), inCM(1)));
        deadlineBlock[i].setFillColor(sf::Color(217, 217, 217));
        deadlineBlock[i].setPosition(categoryBlock.getPosition().x + inCM(1.2125) * i, categoryBlock.getPosition().y + inCM(2.22));
    }
    //deadline typed
    std::string FMdeadline[5];
    for(int i = 0; i < 5; i++)
        FMdeadline[i] = "";
    sf::Text FMdeadlineTyped[5];
    for(int i = 0; i < 5; i++)
    {
        FMdeadlineTyped[i].setString(FMdeadline[i]);
        FMdeadlineTyped[i].setFont(calibri_normal);
        FMdeadlineTyped[i].setCharacterSize(font_resize(12));
        FMdeadlineTyped[i].setFillColor(sf::Color(100, 100, 100));
        FMdeadlineTyped[i].setPosition(deadlineBlock[i].getPosition() + sf::Vector2f(inCM(0.2), inCM(0.2)));
    }
    //deadline block text
    sf::Text deadlineBlockText[5];
    deadlineBlockText[0].setString("[y]");
    deadlineBlockText[1].setString("[m]");
    deadlineBlockText[2].setString("[d]");
    deadlineBlockText[3].setString("[h]");
    deadlineBlockText[4].setString("[m]");
    for(int i = 0; i < 5; i++)
    {
        deadlineBlockText[i].setFont(calibri_normal);
        deadlineBlockText[i].setCharacterSize(font_resize(14));
        deadlineBlockText[i].setFillColor(sf::Color(255, 255, 255));
        deadlineBlockText[i].setPosition(deadlineBlock[i].getPosition() + sf::Vector2f(deadlineBlock[i].getSize().x / 2 - deadlineBlockText[i].getLocalBounds().width / 2, inCM(0.15)));
    }
    //duration text
    sf::Text durationText;
    durationText.setString("Duration");
    durationText.setFont(calibri_italic);
    durationText.setFillColor(sf::Color(62, 149, 164));
    durationText.setCharacterSize(font_resize(18));
    durationText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - durationText.getLocalBounds().width / 2, deadlineText.getPosition().y + inCM(2.22));
    //duration block
    bool FMdurationBlockOn[2] = {false, false};
    sf::RectangleShape durationBlock[2];
    for(int i = 0; i < 2; i++)
    {
        durationBlock[i].setSize(sf::Vector2f(inCM(2.98), inCM(1)));
        durationBlock[i].setFillColor(sf::Color(217, 217, 217));
        durationBlock[i].setPosition(categoryBlock.getPosition().x + inCM(3.04) * i, deadlineBlock[0].getPosition().y + inCM(2.22));
    }
    //duration block typed
    std::string duration[2] = {""};
    sf::Text durationTyped[2];
    for(int i = 0; i < 2; i++)
    {
        durationTyped[i].setString(duration[i]);
        durationTyped[i].setFont(calibri_normal);
        durationTyped[i].setCharacterSize(font_resize(15));
        durationTyped[i].setFillColor(sf::Color(100, 100, 100));
        durationTyped[i].setPosition(durationBlock[i].getPosition() + sf::Vector2f(inCM(0.49), inCM(0.1)));
    }
    //duration block text
    sf::Text durationBlockText[2];
    durationBlockText[0].setString("[h]");
    durationBlockText[1].setString("[m]");
    for(int i = 0; i < 2; i++)
    {
        durationBlockText[i].setFont(calibri_normal);
        durationBlockText[i].setCharacterSize(font_resize(14));
        durationBlockText[i].setFillColor(sf::Color(255, 255, 255));
        durationBlockText[i].setPosition(durationBlock[i].getPosition() + sf::Vector2f(durationBlock[i].getSize().x / 2 - durationBlockText[i].getLocalBounds().width / 2, inCM(0.15)));
    }
    //max continuous duration text
    sf::Text maxContiDurationText;
    maxContiDurationText.setString("Max Continuous Duration");
    maxContiDurationText.setFont(calibri_italic);
    maxContiDurationText.setFillColor(sf::Color(62, 149, 164));
    maxContiDurationText.setCharacterSize(font_resize(18));
    maxContiDurationText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - maxContiDurationText.getLocalBounds().width / 2, durationText.getPosition().y + inCM(2.22));
    //max continuous duration block
    bool maxContiDurationBlockOn[2] = {false, false};
    sf::RectangleShape maxContiDurationBlock[2];
    for(int i = 0; i < 2; i++)
    {
        maxContiDurationBlock[i].setSize(sf::Vector2f(inCM(2.98), inCM(1)));
        maxContiDurationBlock[i].setFillColor(sf::Color(217, 217, 217));
        maxContiDurationBlock[i].setPosition(durationBlock[i].getPosition() + sf::Vector2f(0, inCM(2.22)));
    }
    //max continuous duration typed
    std::string maxContiDuration[2] = {"", ""};
    sf::Text maxContiDurationTyped[2];
    for(int i = 0; i < 2; i++)
    {
        maxContiDurationTyped[i].setString(maxContiDuration[i]);
        maxContiDurationTyped[i].setFont(calibri_normal);
        maxContiDurationTyped[i].setCharacterSize(font_resize(15));
        maxContiDurationTyped[i].setFillColor(sf::Color(100, 100, 100));
        maxContiDurationTyped[i].setPosition(maxContiDurationBlock[i].getPosition() + sf::Vector2f(inCM(0.49), inCM(0.1)));
    }
    //max continuous duration block text
    sf::Text maxContiDurationBlockText[2];
    maxContiDurationBlockText[0].setString("[h]");
    maxContiDurationBlockText[1].setString("[m]");
    for(int i = 0; i < 2; i++)
    {
        maxContiDurationBlockText[i].setFont(calibri_normal);
        maxContiDurationBlockText[i].setCharacterSize(font_resize(14));
        maxContiDurationBlockText[i].setFillColor(sf::Color(255, 255, 255));
        maxContiDurationBlockText[i].setPosition(durationBlockText[i].getPosition() + sf::Vector2f(0, inCM(2.22)));
    }
    //priority text
    sf::Text priorityText;
    priorityText.setString("Priority");
    priorityText.setFont(calibri_italic);
    priorityText.setCharacterSize(font_resize(18));
    priorityText.setFillColor(sf::Color(62, 149, 164));
    priorityText.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x / 2 - priorityText.getLocalBounds().width / 2, maxContiDurationText.getPosition().y + inCM(2.22));
    //priority block
    bool priorityBlockOn = false;
    sf::RectangleShape priorityBlock(sf::Vector2f(inCM(6), inCM(1)));
    priorityBlock.setFillColor(sf::Color(217, 217, 217));
    priorityBlock.setPosition(maxContiDurationBlock[0].getPosition() + sf::Vector2f(0, inCM(2.22)));
    //priority typed
    std::string priority = "";
    sf::Text priorityTyped;
    priorityTyped.setString(priority);
    priorityTyped.setFont(calibri_normal);
    priorityTyped.setCharacterSize(font_resize(15));
    priorityTyped.setFillColor(sf::Color(100, 100, 100));
    priorityTyped.setPosition(priorityBlock.getPosition().x + priorityBlock.getSize().x / 2 - priorityTyped.getLocalBounds().width / 2, priorityBlock.getPosition().y + inCM(0.15));
    //priority block text
    sf::Text priorityBlockText;
    priorityBlockText.setString("1, 2, ..., 10");
    priorityBlockText.setFillColor(sf::Color(255, 255, 255));
    priorityBlockText.setCharacterSize(font_resize(14));
    priorityBlockText.setFont(calibri_normal);
    priorityBlockText.setPosition(priorityBlock.getPosition().x + priorityBlock.getSize().x / 2 - priorityBlockText.getLocalBounds().width / 2, maxContiDurationBlockText[0].getPosition().y + inCM(2.22));
    //add button
    sf::RectangleShape FMaddButton(sf::Vector2f(inCM(3), inCM(0.8)));
    FMaddButton.setFillColor(sf::Color(162, 219, 214));
    FMaddButton.setPosition(FMmenu.getPosition().x + inCM(1.5), FMmenu.getPosition().y + FMmenu.getSize().y - inCM(1.6));
    //add button text
    sf::Text FMaddButtonText;
    FMaddButtonText.setString("add");
    FMaddButtonText.setFont(calibri_normal);
    FMaddButtonText.setCharacterSize(font_resize(18));
    FMaddButtonText.setFillColor(sf::Color(62, 149, 164));
    FMaddButtonText.setPosition(FMaddButton.getPosition().x + FMaddButton.getSize().x / 2 - FMaddButtonText.getLocalBounds().width / 2, FMaddButton.getPosition().y);
    //cancel button
    sf::RectangleShape FMcancelButton(sf::Vector2f(inCM(3), inCM(0.8)));
    FMcancelButton.setFillColor(sf::Color(162, 219, 214));
    FMcancelButton.setPosition(FMmenu.getPosition().x + FMmenu.getSize().x - inCM(1.5) - FMcancelButton.getSize().x, FMaddButton.getPosition().y);
    //cancel button text
    sf::Text FMcancelButtonText;
    FMcancelButtonText.setString("cancel");
    FMcancelButtonText.setFont(calibri_normal);
    FMcancelButtonText.setCharacterSize(font_resize(18));
    FMcancelButtonText.setFillColor(sf::Color(62, 149, 164));
    FMcancelButtonText.setPosition(FMcancelButton.getPosition().x + FMcancelButton.getSize().x / 2 - FMcancelButtonText.getLocalBounds().width / 2, FMcancelButton.getPosition().y);

    //add fixed time event/////////////////////////////////////////////////////////////////////////////////
    bool FEmenuOn = false;
    sf::RectangleShape FEmenu(sf::Vector2f(inCM(12), inCM(15)));
    FEmenu.setFillColor(sf::Color(255, 255, 255, 243));
    FEmenu.setPosition(800 + inCM(1.5) - FEmenu.getSize().x / 2, 450 - FEmenu.getSize().y / 2);
    //add fixed time event title
    sf::Text FEmenuTitle;
    FEmenuTitle.setString("Add Fixed Time Event");
    FEmenuTitle.setFont(calibri_bold);
    FEmenuTitle.setCharacterSize(font_resize(20));
    FEmenuTitle.setFillColor(sf::Color(62, 149, 164));
    FEmenuTitle.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - FEmenuTitle.getLocalBounds().width / 2, FEmenu.getPosition().y + inCM(1.5));
    //event name text
    sf::Text eventNameText;
    eventNameText.setString("Event Name");
    eventNameText.setFont(calibri_italic);
    eventNameText.setCharacterSize(font_resize(18));
    eventNameText.setFillColor(sf::Color(62, 149, 164));
    eventNameText.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - eventNameText.getLocalBounds().width / 2, FEmenu.getPosition().y + inCM(3.2));
    //event name block
    bool eventNameBlockOn = false;
    sf::RectangleShape eventNameBlock(sf::Vector2f(inCM(6), inCM(1)));
    eventNameBlock.setFillColor(sf::Color(217, 217, 217));
    eventNameBlock.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - eventNameBlock.getSize().x / 2, FEmenu.getPosition().y + inCM(4.2));
    //event name typed
    std::string eventName = "";
    sf::Text eventNameTyped;
    eventNameTyped.setString(eventName);
    eventNameTyped.setFont(calibri_normal);
    eventNameTyped.setCharacterSize(font_resize(15));
    eventNameTyped.setFillColor(sf::Color(100, 100, 100));
    eventNameTyped.setPosition(eventNameBlock.getPosition() + sf::Vector2f(inCM(0.5), inCM(0.1)));
    //FE category text
    sf::Text FEcategoryText;
    FEcategoryText.setString("Category");
    FEcategoryText.setFillColor(sf::Color(62, 149, 164));
    FEcategoryText.setFont(calibri_italic);
    FEcategoryText.setCharacterSize(font_resize(18));
    FEcategoryText.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - FEcategoryText.getLocalBounds().width / 2, eventNameText.getPosition().y + inCM(2.22));
    //FE category block
    bool FEcategoryBlockOn = false;
    sf::RectangleShape FEcategoryBlock(sf::Vector2f(inCM(6), inCM(1)));
    FEcategoryBlock.setFillColor(sf::Color(217, 217, 217));
    FEcategoryBlock.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - FEcategoryBlock.getSize().x / 2, eventNameBlock.getPosition().y + inCM(2.22));
    //FE category typed
    std::string FEcategory = "";
    sf::Text FEcategoryTyped;
    FEcategoryTyped.setString(FEcategory);
    FEcategoryTyped.setFont(calibri_normal);
    FEcategoryTyped.setCharacterSize(font_resize(15));
    FEcategoryTyped.setFillColor(sf::Color(100, 100, 100));
    FEcategoryTyped.setPosition(FEcategoryBlock.getPosition() + sf::Vector2f(inCM(0.5), inCM(0.1)));
    //FE start time text
    sf::Text FEstartTimeText;
    FEstartTimeText.setString("Start Time");
    FEstartTimeText.setFont(calibri_italic);
    FEstartTimeText.setCharacterSize(font_resize(18));
    FEstartTimeText.setFillColor(sf::Color(62, 149, 164));
    FEstartTimeText.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - FEstartTimeText.getLocalBounds().width / 2, FEcategoryText.getPosition().y + inCM(2.22));
    //FE start time block
    bool FEstartTimeBlockOn[5];
    for(int i = 0; i < 5; i++)
        FEstartTimeBlockOn[i] = false;
    sf::RectangleShape FEstartTimeBlock[5];
    for(int i = 0; i < 5; i++)
    {
        FEstartTimeBlock[i].setSize(sf::Vector2f(inCM(1.15), inCM(1)));
        FEstartTimeBlock[i].setFillColor(sf::Color(217, 217, 217));
        FEstartTimeBlock[i].setPosition(FEcategoryBlock.getPosition().x + inCM(1.15 + 0.0625) * i, FEcategoryBlock.getPosition().y + inCM(2.22));
    }
    //FE start time block typed
    std::string FEstartTime[5];
    for(int i = 0; i < 5; i++)
        FEstartTime[i] = "";
    sf::Text FEstartTimeTyped[5];
    for(int i = 0; i < 5; i++)
    {
        FEstartTimeTyped[i].setString(FEstartTime[i]);
        FEstartTimeTyped[i].setFont(calibri_normal);
        FEstartTimeTyped[i].setCharacterSize(font_resize(12));
        FEstartTimeTyped[i].setFillColor(sf::Color(100, 100, 100));
        FEstartTimeTyped[i].setPosition(FEstartTimeBlock[i].getPosition().x + FEstartTimeBlock[i].getSize().x / 2 - FEstartTimeTyped[i].getLocalBounds().width / 2, FEstartTimeBlock[i].getPosition().y + inCM(0.15));
    }
    //FE start time block text
    sf::Text FEstartTimeBlockText[5];
    FEstartTimeBlockText[0].setString("[y]");
    FEstartTimeBlockText[1].setString("[m]");
    FEstartTimeBlockText[2].setString("[d]");
    FEstartTimeBlockText[3].setString("[h]");
    FEstartTimeBlockText[4].setString("[m]");
    for(int i = 0; i < 5; i++)
    {
        FEstartTimeBlockText[i].setFont(calibri_normal);
        FEstartTimeBlockText[i].setCharacterSize(font_resize(14));
        FEstartTimeBlockText[i].setFillColor(sf::Color(255, 255, 255));
        FEstartTimeBlockText[i].setPosition(FEstartTimeBlock[i].getPosition() + sf::Vector2f(FEstartTimeBlock[i].getSize().x / 2 - FEstartTimeBlockText[i].getLocalBounds().width / 2, inCM(0.15)));
    }
    //FE end time text
    sf::Text FEendTimeText;
    FEendTimeText.setString("End Time");
    FEendTimeText.setFont(calibri_italic);
    FEendTimeText.setCharacterSize(font_resize(18));
    FEendTimeText.setFillColor(sf::Color(62, 149, 164));
    FEendTimeText.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x / 2 - FEendTimeText.getLocalBounds().width / 2, FEstartTimeText.getPosition().y + inCM(2.22));
    //FE end time block
    bool FEendTimeBlockOn[5];
    for(int i = 0; i < 5; i++)
        FEendTimeBlockOn[i] = false;
    sf::RectangleShape FEendTimeBlock[5];
    for(int i = 0; i < 5; i++)
    {
        FEendTimeBlock[i].setSize(sf::Vector2f(inCM(1.15), inCM(1)));
        FEendTimeBlock[i].setFillColor(sf::Color(217, 217, 217));
        FEendTimeBlock[i].setPosition(FEcategoryBlock.getPosition().x + inCM(1.15 + 0.0625) * i, FEstartTimeBlock[0].getPosition().y + inCM(2.22));
    }
    //FE end time typed
    std::string FEendTime[5];
    for(int i = 0; i < 5; i++)
        FEendTime[i] = "";
    sf::Text FEendTimeTyped[5];
    for(int i = 0; i < 5; i++)
    {
        FEendTimeTyped[i].setString(FEendTime[i]);
        FEendTimeTyped[i].setFont(calibri_normal);
        FEendTimeTyped[i].setCharacterSize(font_resize(12));
        FEendTimeTyped[i].setFillColor(sf::Color(100, 100, 100));
        FEendTimeTyped[i].setPosition(FEendTimeBlock[i].getPosition().x + FEendTimeBlock[i].getSize().x / 2 - FEendTimeTyped[i].getLocalBounds().width / 2, FEendTimeBlock[i].getPosition().y + inCM(0.15));
    }
    //FE end time block text
    sf::Text FEendTimeBlockText[5];
    FEendTimeBlockText[0].setString("[y]");
    FEendTimeBlockText[1].setString("[m]");
    FEendTimeBlockText[2].setString("[d]");
    FEendTimeBlockText[3].setString("[h]");
    FEendTimeBlockText[4].setString("[m]");
    for(int i = 0; i < 5; i++)
    {
        FEendTimeBlockText[i].setFont(calibri_normal);
        FEendTimeBlockText[i].setCharacterSize(font_resize(14));
        FEendTimeBlockText[i].setFillColor(sf::Color(255, 255, 255));
        FEendTimeBlockText[i].setPosition(FEendTimeBlock[i].getPosition() + sf::Vector2f(FEendTimeBlock[i].getSize().x / 2 - FEendTimeBlockText[i].getLocalBounds().width / 2, inCM(0.15)));
    }
    //add button
    sf::RectangleShape FEaddButton(sf::Vector2f(inCM(3), inCM(0.8)));
    FEaddButton.setFillColor(sf::Color(162, 219, 214));
    FEaddButton.setPosition(FEmenu.getPosition().x + inCM(1.5), FEmenu.getPosition().y + FEmenu.getSize().y - inCM(2));
    //add button text
    sf::Text FEaddButtonText;
    FEaddButtonText.setString("add");
    FEaddButtonText.setFont(calibri_normal);
    FEaddButtonText.setCharacterSize(font_resize(18));
    FEaddButtonText.setFillColor(sf::Color(62, 149, 164));
    FEaddButtonText.setPosition(FEaddButton.getPosition().x + FEaddButton.getSize().x / 2 - FEaddButtonText.getLocalBounds().width / 2, FEaddButton.getPosition().y);
    //cancel button
    sf::RectangleShape FEcancelButton(sf::Vector2f(inCM(3), inCM(0.8)));
    FEcancelButton.setFillColor(sf::Color(162, 219, 214));
    FEcancelButton.setPosition(FEmenu.getPosition().x + FEmenu.getSize().x - inCM(1.5) - FEcancelButton.getSize().x, FEaddButton.getPosition().y);
    //cancel button text
    sf::Text FEcancelButtonText;
    FEcancelButtonText.setString("cancel");
    FEcancelButtonText.setFont(calibri_normal);
    FEcancelButtonText.setCharacterSize(font_resize(18));
    FEcancelButtonText.setFillColor(sf::Color(62, 149, 164));
    FEcancelButtonText.setPosition(FEcancelButton.getPosition().x + FEcancelButton.getSize().x / 2 - FEcancelButtonText.getLocalBounds().width / 2, FEcancelButton.getPosition().y);

    //invalid menu
    bool invalidMenuOn = false;
    bool invalidMenu_m = false;
    sf::RectangleShape invalidFilter(sf::Vector2f(1600 - inCM(1.5), 900));
    invalidFilter.setFillColor(sf::Color(0, 0, 0, 50));
    invalidFilter.setPosition(inCM(1.5), 0);
    sf::RectangleShape invalidMenu(sf::Vector2f(inCM(10), inCM(6)));
    invalidMenu.setFillColor(sf::Color(255, 255, 255));
    invalidMenu.setOutlineThickness(inCM(0.2));
    invalidMenu.setOutlineColor(sf::Color(157, 215, 208));
    invalidMenu.setPosition(800 + inCM(1.5) - invalidMenu.getSize().x / 2, 450 - invalidMenu.getSize().y / 2);
    //invalid text
    sf::Text invalidText;
    invalidText.setString("                !!! INVALID INPUT !!!         \nTime Occpupied or Invalid Time Input");
    invalidText.setFillColor(sf::Color(62, 149, 164));
    invalidText.setCharacterSize(font_resize(16));
    invalidText.setFont(calibri_bold);
    invalidText.setPosition(invalidMenu.getPosition().x + invalidMenu.getSize().x / 2 - invalidText.getLocalBounds().width / 2, invalidMenu.getPosition().y + inCM(2));
    //close button
    sf::RectangleShape closeButton(sf::Vector2f(inCM(3), inCM(1)));
    closeButton.setFillColor(sf::Color(162, 219, 214));
    closeButton.setPosition(invalidMenu.getPosition().x + invalidMenu.getSize().x / 2 - closeButton.getSize().x / 2, invalidMenu.getPosition().y + invalidMenu.getSize().y - inCM(2));
    //close button text
    sf::Text closeButtonText;
    closeButtonText.setString("close");
    closeButtonText.setFont(calibri_normal);
    closeButtonText.setCharacterSize(font_resize(18));
    closeButtonText.setFillColor(sf::Color(62, 149, 164));
    closeButtonText.setPosition(closeButton.getPosition().x + closeButton.getSize().x / 2 - closeButtonText.getLocalBounds().width / 2, closeButton.getPosition().y + inCM(0.1));

    //successfully add menu
    bool sAddMenuOn = false;
    bool sAdd_m = false;
    sf::RectangleShape sAddMenu(sf::Vector2f(inCM(10), inCM(6)));
    sAddMenu.setFillColor(sf::Color(230, 246, 244));
    sAddMenu.setOutlineThickness(inCM(0.2));
    sAddMenu.setOutlineColor(sf::Color(148, 216, 208));
    sAddMenu.setPosition(800 + inCM(1.5) - sAddMenu.getSize().x / 2, 450 - sAddMenu.getSize().y / 2);
    //successfully add menu text
    sf::Text sAddText;
    sAddText.setString("\"Sucessfully Add\"");
    sAddText.setFont(calibri_bold);
    sAddText.setCharacterSize(font_resize(20));
    sAddText.setFillColor(sf::Color(62, 149, 164));
    sAddText.setPosition(sAddMenu.getPosition().x + sAddMenu.getSize().x / 2 - sAddText.getLocalBounds().width / 2, sAddMenu.getPosition().y + inCM(2));
    //sClose button
    sf::RectangleShape sCloseButton(sf::Vector2f(inCM(3), inCM(1)));
    sCloseButton.setFillColor(sf::Color(162, 219, 214));
    sCloseButton.setPosition(sAddMenu.getPosition().x + sAddMenu.getSize().x / 2 - sCloseButton.getSize().x / 2, sAddMenu.getPosition().y + sAddMenu.getSize().y - inCM(2));
    //sClose text
    sf::Text sCloseButtonText;
    sCloseButtonText.setString("close");
    sCloseButtonText.setFillColor(sf::Color(62, 149, 164));
    sCloseButtonText.setFont(calibri_normal);
    sCloseButtonText.setCharacterSize(font_resize(18));
    sCloseButtonText.setPosition(sCloseButton.getPosition().x + sCloseButton.getSize().x / 2 - sCloseButtonText.getLocalBounds().width / 2, sCloseButton.getPosition().y + inCM(0.1));



    //too full menu
    bool tooFullMenuOn = false;
    sf::RectangleShape tooFullFilter(sf::Vector2f(1600 - inCM(1.5), 900));
    tooFullFilter.setFillColor(sf::Color(0, 0, 0, 150));
    tooFullFilter.setPosition(inCM(1.5), 0);
    sf::RectangleShape tooFullMenu(sf::Vector2f(inCM(10), inCM(6)));
    tooFullMenu.setFillColor(sf::Color(255, 255, 255));
    tooFullMenu.setOutlineThickness(inCM(0.2));
    tooFullMenu.setOutlineColor(sf::Color(157, 215, 208));
    tooFullMenu.setPosition(800 + inCM(1.5) - tooFullMenu.getSize().x / 2, 450 - tooFullMenu.getSize().y / 2);
    //invalid text
    sf::Text tooFullText;
    tooFullText.setString("Not Enough Time To Schedule Your Missions!\n");
    tooFullText.setFillColor(sf::Color(62, 149, 164));
    tooFullText.setCharacterSize(font_resize(13.5));
    tooFullText.setFont(calibri_bold);
    tooFullText.setPosition(tooFullMenu.getPosition().x + tooFullMenu.getSize().x / 2 - tooFullText.getLocalBounds().width / 2, tooFullMenu.getPosition().y + inCM(2));
    //close button
    sf::RectangleShape tCloseButton(sf::Vector2f(inCM(3), inCM(1)));
    tCloseButton.setFillColor(sf::Color(162, 219, 214));
    tCloseButton.setPosition(tooFullMenu.getPosition().x + tooFullMenu.getSize().x / 2 - tCloseButton.getSize().x / 2, tooFullMenu.getPosition().y + tooFullMenu.getSize().y - inCM(2));
    //close button text
    sf::Text tCloseButtonText;
    tCloseButtonText.setString("close");
    tCloseButtonText.setFont(calibri_normal);
    tCloseButtonText.setCharacterSize(font_resize(18));
    tCloseButtonText.setFillColor(sf::Color(62, 149, 164));
    tCloseButtonText.setPosition(tCloseButton.getPosition().x + tCloseButton.getSize().x / 2 - tCloseButtonText.getLocalBounds().width / 2, tCloseButton.getPosition().y + inCM(0.1));


    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            year2018[i][j] = new Day(start);
            start = start + 1440;
        }
    }
  
//    cout << "done initializing year2018" << endl;
//    cout << "going into adding FE into year2018" << endl;
    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            for(int k=0;k<FEBag.Bag.get_itemCount();k++)
            {
                string FEtime = FEBag.Bag[k]->GetstartTime().substr(0,8);
                string cur = year2018[i][j]->getToday().substr(0,8);
                if(FEtime==cur)
                {
                    year2018[i][j]->addFixedEvent(FEBag.Bag[k]);
                }
                else
                    continue;
            }
            year2018[i][j]->showToday();
        }
    }
//    cout << "finish adding FE into year2018" << endl;
//    cout << "start adding mission into year2018" << endl;
    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            for(int k=0;k<MBag.Bag.get_itemCount();k++)
            {
                string Mtime = MBag.Bag[k]->GetstartTime().substr(0,8);
                string cur = year2018[i][j]->getToday().substr(0,8);
                if(Mtime==cur)
                    year2018[i][j]->RestoreMission(MBag.Bag[k]);
                else
                    continue;
            }
//            year2018[i][j]->showToday();

        }
    }
//    cout << "finish adding Mission into year2018" << endl;
    for(int i=0;i<FEBag.Bag.get_itemCount();i++)
    {
        week[0]->addFixedEvent(FEBag.Bag[i]);
    }
    for(int i=0;i<MBag.Bag.get_itemCount();i++)
    {
        week[0]->RestoreMission(MBag.Bag[i]);
    }


    //-----------------------CHAO -> initialize variables

    //Remove, Check, Close of Mes Box
    sf::RectangleShape BoxMes_Button[3];
    //Check if there is aother box opened
    bool NoOtherMesBox=true;
    int move_page = 0;

    sf::RectangleShape RS[1000];

    while (window.isOpen())
    {
        sf::Event event;


        while (passwordCorrect == false && window.pollEvent(event) && !page2 && !page3)
        {
            //"text input" event
            if (event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode >= 32 && event.text.unicode < 128)
                {
                    password += "*";
                    passwordStr += event.text.unicode;
                }
                else if (event.text.unicode == 8 && password.getSize() > 0)
                {
                    password.erase(password.getSize() - 1, password.getSize());
                    passwordStr.erase(passwordStr.length() - 1, passwordStr.length());
                }
            }
            userText.setString(password);

            //"enter press" event
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
            {
                if(userpassword==passwordStr)
                {
                    cout << passwordStr << endl;
                    passwordCorrect = true;
                    page2 = true;
                    break;
                }

                else
                {
                    password = "";
                    passwordStr = "";
                }

            }

            //"window close" event
            if (event.type == sf::Event::Closed)
            {
                MBag.SaveFile(MissionLocation);
                FEBag.SaveFile(FixedLocation);
                window.close();
            }
        }






        while (window.pollEvent(event) && passwordCorrect==true && page2)
        {

            /*CHAO*/
            //close window
            if(event.type == sf::Event::Closed)
            {
                MBag.SaveFile(MissionLocation);
                FEBag.SaveFile(FixedLocation);
                window.close();
            }
            //check if the user click the box for detail
            if(  sf::Mouse::isButtonPressed(sf::Mouse::Left)  )
            {
                if(MouseOnBoxes(window, RS, TotalBoxes)!=-1 &&NoOtherMesBox && !FMmenuOn && !selectEventMenuOn && !FEmenuOn && !sAddMenuOn && !invalidMenuOn)
                {
                    BoxIndex = MouseOnBoxes(window, RS, TotalBoxes);
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                    DisplayBox = true;
                }

                //check if the user click the buttons in the box
                if(MouseOnBoxes(window, BoxMes_Button, 3)!=-1 && !FMmenuOn && !selectEventMenuOn && !FEmenuOn && !sAddMenuOn && !invalidMenuOn)
                {
                    BoxMes_Button_index = MouseOnBoxes(window, BoxMes_Button, 3);
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }

                //check if the user turn the page
                if(MouseOnTurnPage(window, leftButton, rightButton)!=0 && !FMmenuOn && !selectEventMenuOn && !FEmenuOn && !sAddMenuOn && !invalidMenuOn)
                {
                    move_page += MouseOnTurnPage(window, leftButton, rightButton);
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                /*CHAO*/
            }
            //type FM mission name
            if(missionNameBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && missionName.length() != 0)
                    missionName.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && missionNameTyped.getLocalBounds().width < inCM(4.8))
                    missionName += static_cast<char>(event.text.unicode);
                missionNameTyped.setString(missionName);
                missionNameTyped.setPosition(missionNameBlock.getPosition().x + missionNameBlock.getSize().x / 2 - missionNameTyped.getLocalBounds().width / 2, missionNameBlock.getPosition().y + inCM(0.15));
            }
            //type FM category
            if(categoryBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && FMcategory.length() != 0)
                    FMcategory.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && FMcategoryTyped.getLocalBounds().width < inCM(4.8))
                    FMcategory += static_cast<char>(event.text.unicode);
                FMcategoryTyped.setString(FMcategory);
                FMcategoryTyped.setPosition(categoryBlock.getPosition().x + categoryBlock.getSize().x / 2- FMcategoryTyped.getLocalBounds().width / 2, categoryBlock.getPosition().y + inCM(0.15));
            }
            //type FM deadline
            for(int i = 0; i < 5; i++)
            {
                if(deadlineBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FMdeadline[i].length() != 0)
                        FMdeadline[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FMdeadlineTyped[i].getLocalBounds().width < inCM(0.9))
                        FMdeadline[i] += static_cast<char>(event.text.unicode);
                    FMdeadlineTyped[i].setString(FMdeadline[i]);
                    FMdeadlineTyped[i].setPosition(deadlineBlock[i].getPosition().x + deadlineBlock[i].getSize().x / 2 - FMdeadlineTyped[i].getLocalBounds().width / 2, deadlineBlock[i].getPosition().y + inCM(0.2));
                }
            }
            //type FM duration
            for(int i = 0; i < 2; i++)
            {
                if(FMdurationBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && duration[i].length() != 0)
                        duration[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && durationTyped[i].getLocalBounds().width < inCM(2.3))
                        duration[i] += static_cast<char>(event.text.unicode);
                    durationTyped[i].setString(duration[i]);
                    durationTyped[i].setPosition(durationBlock[i].getPosition().x + durationBlock[i].getSize().x / 2 - durationTyped[i].getLocalBounds().width / 2, durationBlock[i].getPosition().y + inCM(0.15));
                }
            }
            //type FM max continuous duration
            for(int i = 0; i < 2; i++)
            {
                if(maxContiDurationBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && maxContiDuration[i].length() != 0)
                        maxContiDuration[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && maxContiDurationTyped[i].getLocalBounds().width < inCM(2.3))
                        maxContiDuration[i] += static_cast<char>(event.text.unicode);
                    maxContiDurationTyped[i].setString(maxContiDuration[i]);
                    maxContiDurationTyped[i].setPosition(maxContiDurationBlock[i].getPosition().x + maxContiDurationBlock[i].getSize().x / 2 - maxContiDurationTyped[i].getLocalBounds().width / 2, maxContiDurationBlock[i].getPosition().y + inCM(0.15));
                }
            }
            //type priority
            if(priorityBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && priority.length() != 0)
                    priority.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && priorityTyped.getLocalBounds().width < inCM(4.8))
                    priority += static_cast<char>(event.text.unicode);
                priorityTyped.setString(priority);
                priorityTyped.setPosition(priorityBlock.getPosition().x + priorityBlock.getSize().x / 2- priorityTyped.getLocalBounds().width / 2, priorityBlock.getPosition().y + inCM(0.15));

            }
            //type FE event name
            if(eventNameBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && eventName.length() != 0)
                    eventName.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && eventNameTyped.getLocalBounds().width < inCM(4.8))
                    eventName += static_cast<char>(event.text.unicode);
                eventNameTyped.setString(eventName);
                eventNameTyped.setPosition(eventNameBlock.getPosition().x + eventNameBlock.getSize().x / 2 - eventNameTyped.getLocalBounds().width / 2, eventNameBlock.getPosition().y + inCM(0.15));
            }
            //type FE category
            if(FEcategoryBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && FEcategory.length() != 0)
                    FEcategory.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && FEcategoryTyped.getLocalBounds().width < inCM(4.8))
                    FEcategory += static_cast<char>(event.text.unicode);
                FEcategoryTyped.setString(FEcategory);
                FEcategoryTyped.setPosition(FEcategoryBlock.getPosition().x + FEcategoryBlock.getSize().x / 2 - FEcategoryTyped.getLocalBounds().width / 2, FEcategoryBlock.getPosition().y + inCM(0.15));
            }
            //type FE start time
            for(int i = 0; i < 5; i++)
            {
                if(FEstartTimeBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FEstartTime[i].length() != 0)
                        FEstartTime[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FEstartTimeTyped[i].getLocalBounds().width < inCM(0.9))
                        FEstartTime[i] += static_cast<char>(event.text.unicode);
                    FEstartTimeTyped[i].setString(FEstartTime[i]);
                    FEstartTimeTyped[i].setPosition(FEstartTimeBlock[i].getPosition().x + FEstartTimeBlock[i].getSize().x / 2 - FEstartTimeTyped[i].getLocalBounds().width / 2, FEstartTimeBlock[i].getPosition().y + inCM(0.2));
                }
            }
            //type FE end time
            for(int i = 0; i < 5; i++)
            {
                if(FEendTimeBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FEendTime[i].length() != 0)
                        FEendTime[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FEendTimeTyped[i].getLocalBounds().width < inCM(0.9))
                        FEendTime[i] += static_cast<char>(event.text.unicode);
                    FEendTimeTyped[i].setString(FEendTime[i]);
                    FEendTimeTyped[i].setPosition(FEendTimeBlock[i].getPosition().x + FEendTimeBlock[i].getSize().x / 2 - FEendTimeTyped[i].getLocalBounds().width / 2, FEendTimeBlock[i].getPosition().y + inCM(0.15));
                }
            }

        }
        
        while (window.pollEvent(event) && passwordCorrect==true && page3)
        {
            if (event.type == sf::Event::Closed)
            {
                MBag.SaveFile(MissionLocation);
                FEBag.SaveFile(FixedLocation);
                window.close();
            }
            if (event.mouseButton.button == sf::Mouse::Left)
            {

                if (MouseOnBarSW(window))
                {
                    Bar2PieSW = 0;
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if (MouseOnPieSW(window))
                {
                    Bar2PieSW = 1;
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if(MouseOnPieScale(window, w))
                {
                    Pie_scale="W";
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if(MouseOnPieScale(window, m))
                {
                    Pie_scale="M";
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if(MouseOnPieScale(window, y))
                {
                    Pie_scale="Y";
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if(MouseOnLBarSW(window, d))
                {
                    RBar_scale = "D";
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
                if(MouseOnLBarSW(window, w))
                {
                    RBar_scale = "W";
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                }
            }
            
            
            //type FM mission name
            if(missionNameBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && missionName.length() != 0)
                    missionName.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && missionNameTyped.getLocalBounds().width < inCM(4.8))
                    missionName += static_cast<char>(event.text.unicode);
                missionNameTyped.setString(missionName);
                missionNameTyped.setPosition(missionNameBlock.getPosition().x + missionNameBlock.getSize().x / 2 - missionNameTyped.getLocalBounds().width / 2, missionNameBlock.getPosition().y + inCM(0.15));
            }
            //type FM category
            if(categoryBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && FMcategory.length() != 0)
                    FMcategory.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && FMcategoryTyped.getLocalBounds().width < inCM(4.8))
                    FMcategory += static_cast<char>(event.text.unicode);
                FMcategoryTyped.setString(FMcategory);
                FMcategoryTyped.setPosition(categoryBlock.getPosition().x + categoryBlock.getSize().x / 2- FMcategoryTyped.getLocalBounds().width / 2, categoryBlock.getPosition().y + inCM(0.15));
            }
            //type FM deadline
            for(int i = 0; i < 5; i++)
            {
                if(deadlineBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FMdeadline[i].length() != 0)
                        FMdeadline[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FMdeadlineTyped[i].getLocalBounds().width < inCM(0.9))
                        FMdeadline[i] += static_cast<char>(event.text.unicode);
                    FMdeadlineTyped[i].setString(FMdeadline[i]);
                    FMdeadlineTyped[i].setPosition(deadlineBlock[i].getPosition().x + deadlineBlock[i].getSize().x / 2 - FMdeadlineTyped[i].getLocalBounds().width / 2, deadlineBlock[i].getPosition().y + inCM(0.2));
                }
            }
            //type FM duration
            for(int i = 0; i < 2; i++)
            {
                if(FMdurationBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && duration[i].length() != 0)
                        duration[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && durationTyped[i].getLocalBounds().width < inCM(2.3))
                        duration[i] += static_cast<char>(event.text.unicode);
                    durationTyped[i].setString(duration[i]);
                    durationTyped[i].setPosition(durationBlock[i].getPosition().x + durationBlock[i].getSize().x / 2 - durationTyped[i].getLocalBounds().width / 2, durationBlock[i].getPosition().y + inCM(0.15));
                }
            }
            //type FM max continuous duration
            for(int i = 0; i < 2; i++)
            {
                if(maxContiDurationBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && maxContiDuration[i].length() != 0)
                        maxContiDuration[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && maxContiDurationTyped[i].getLocalBounds().width < inCM(2.3))
                        maxContiDuration[i] += static_cast<char>(event.text.unicode);
                    maxContiDurationTyped[i].setString(maxContiDuration[i]);
                    maxContiDurationTyped[i].setPosition(maxContiDurationBlock[i].getPosition().x + maxContiDurationBlock[i].getSize().x / 2 - maxContiDurationTyped[i].getLocalBounds().width / 2, maxContiDurationBlock[i].getPosition().y + inCM(0.15));
                }
            }
            //type priority
            if(priorityBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && priority.length() != 0)
                    priority.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && priorityTyped.getLocalBounds().width < inCM(4.8))
                    priority += static_cast<char>(event.text.unicode);
                priorityTyped.setString(priority);
                priorityTyped.setPosition(priorityBlock.getPosition().x + priorityBlock.getSize().x / 2- priorityTyped.getLocalBounds().width / 2, priorityBlock.getPosition().y + inCM(0.15));
                
            }
            //type FE event name
            if(eventNameBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && eventName.length() != 0)
                    eventName.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && eventNameTyped.getLocalBounds().width < inCM(4.8))
                    eventName += static_cast<char>(event.text.unicode);
                eventNameTyped.setString(eventName);
                eventNameTyped.setPosition(eventNameBlock.getPosition().x + eventNameBlock.getSize().x / 2 - eventNameTyped.getLocalBounds().width / 2, eventNameBlock.getPosition().y + inCM(0.15));
            }
            //type FE category
            if(FEcategoryBlockOn == true && event.type == sf::Event::TextEntered)
            {
                if(event.text.unicode == 8 && FEcategory.length() != 0)
                    FEcategory.pop_back();
                else if(event.text.unicode >= 32 && event.text.unicode < 128 && FEcategoryTyped.getLocalBounds().width < inCM(4.8))
                    FEcategory += static_cast<char>(event.text.unicode);
                FEcategoryTyped.setString(FEcategory);
                FEcategoryTyped.setPosition(FEcategoryBlock.getPosition().x + FEcategoryBlock.getSize().x / 2 - FEcategoryTyped.getLocalBounds().width / 2, FEcategoryBlock.getPosition().y + inCM(0.15));
            }
            //type FE start time
            for(int i = 0; i < 5; i++)
            {
                if(FEstartTimeBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FEstartTime[i].length() != 0)
                        FEstartTime[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FEstartTimeTyped[i].getLocalBounds().width < inCM(0.9))
                        FEstartTime[i] += static_cast<char>(event.text.unicode);
                    FEstartTimeTyped[i].setString(FEstartTime[i]);
                    FEstartTimeTyped[i].setPosition(FEstartTimeBlock[i].getPosition().x + FEstartTimeBlock[i].getSize().x / 2 - FEstartTimeTyped[i].getLocalBounds().width / 2, FEstartTimeBlock[i].getPosition().y + inCM(0.2));
                }
            }
            //type FE end time
            for(int i = 0; i < 5; i++)
            {
                if(FEendTimeBlockOn[i] == true && event.type == sf::Event::TextEntered)
                {
                    if(event.text.unicode == 8 && FEendTime[i].length() != 0)
                        FEendTime[i].pop_back();
                    else if(event.text.unicode >= 48 && event.text.unicode <= 57 && FEendTimeTyped[i].getLocalBounds().width < inCM(0.9))
                        FEendTime[i] += static_cast<char>(event.text.unicode);
                    FEendTimeTyped[i].setString(FEendTime[i]);
                    FEendTimeTyped[i].setPosition(FEendTimeBlock[i].getPosition().x + FEendTimeBlock[i].getSize().x / 2 - FEendTimeTyped[i].getLocalBounds().width / 2, FEendTimeBlock[i].getPosition().y + inCM(0.15));
                }
            }

        }

        window.clear(sf::Color::Black);
        if(passwordCorrect == false)
        {
            window.draw(shapeOut);
            window.draw(shape);
            window.draw(line_hour);
            window.draw(line_minute);
            window.draw(center);
            window.draw(text);
            window.draw(text2);
            window.draw(text3);

            // draw loginbar
            window.draw(downRectangle);
            downRectangle.setPosition(0, toPx(14.6 - 1.5));

            // draw login introduction text
            if(passwordStr == "")
                window.draw(loginIntroduction);
            loginIntroduction.setPosition(toPx(3.04), toPx(15.10 - 1.5));

            // draw password
            window.draw(userText);
            userText.setPosition(loginIntroduction.getPosition() + sf::Vector2f(0, inCM(0.15)));
        }
        
        if(page2)
        {


            /*CHAO*/
            if(BoxMes_Button_index==0)//Remove event
            {
                if(BoxIndex>=MBag.Bag.getSize())//FE
                {
                    FEBag.Bag.remove(FEBag.Bag[BoxIndex- MBag.Bag.getSize()]);
                }
                else//Mission
                {
                     MBag.Bag.remove( MBag.Bag[BoxIndex]);
                }
                DisplayBox = false;
                NoOtherMesBox =true;

            }
            if(BoxMes_Button_index==1)//Done Mission
            {
                if(!MBag.Bag[BoxIndex]->GetMisDone())
                {
                    NoOtherMesBox =true;
                    DisplayBox = false;
                }
                if(BoxIndex<MBag.Bag.getSize())//Mission
                    MBag.Bag[BoxIndex]->setIsDone(true);
            }
            else if (BoxMes_Button_index==2)//Close Box information
            {
                NoOtherMesBox =true;
                DisplayBox =false;
            }

        }

        if(page2 || page3)
        {
            sf::Vector2f mousePosition = sf::Vector2f(sf::Mouse::getPosition(window));
            //too full menu on
            if(tooFullMenuOn == true)
            {
                if(tCloseButton.getPosition().x <= mousePosition.x && mousePosition.x <= (tCloseButton.getPosition().x + tCloseButton.getSize().x) && tCloseButton.getPosition().y <= mousePosition.y && mousePosition.y <= (tCloseButton.getPosition().y + tCloseButton.getSize().y))
                {
                    tCloseButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        tooFullMenuOn = false;
                        sAddMenuOn = false;
                        FEmenuOn = false;
                        selectEventMenuOn = false;
                        missionName = "";
                        missionNameTyped.setString(missionName);
                        missionNameBlockOn = false;
                        FMcategory = "";
                        FMcategoryTyped.setString(FMcategory);
                        categoryBlockOn = false;
                        for(int i = 0; i < 5; i++)
                        {
                            FMdeadline[i] = "";
                            FMdeadlineTyped[i].setString(FMdeadline[i]);
                            FMdurationBlockOn[i] = false;
                        }
                        for(int i = 0; i < 2; i++)
                        {
                            duration[i] = "";
                            maxContiDuration[i] = "";
                            durationTyped[i].setString(duration[i]);
                            maxContiDurationTyped[i].setString(maxContiDuration[i]);
                            FMdurationBlockOn[i] = false;
                            maxContiDurationBlockOn[i] = false;
                        }
                        priority = "";
                        priorityTyped.setString(priority);
                        priorityBlockOn = false;
                        eventName = "";
                        eventNameTyped.setString(eventName);
                        FEcategory = "";
                        FEcategoryTyped.setString(FEcategory);
                        for(int i = 0; i < 5; i++)
                        {
                            FEstartTime[i] = "";
                            FEstartTimeTyped[i].setString(FEstartTime[i]);
                            FEendTime[i] = "";
                            FEendTimeTyped[i].setString(FEendTime[i]);
                        }
                        eventNameBlockOn = false;
                        FEcategoryBlockOn = false;
                        for(int i = 0; i < 5; i++)
                        {
                            FEstartTimeBlockOn[i] = false;
                            FEendTimeBlockOn[i] = false;
                        }
                    }
                }
                else
                    tCloseButton.setFillColor(sf::Color(162, 219, 214));
            }




            //sAdd menu on
            if(sAddMenuOn == true)
            {
                if(sCloseButton.getPosition().x <= mousePosition.x && mousePosition.x <= (sCloseButton.getPosition().x + sCloseButton.getSize().x) && sCloseButton.getPosition().y <= mousePosition.y && mousePosition.y <= (sCloseButton.getPosition().y + sCloseButton.getSize().y))
                {
                    sCloseButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        if(sAdd_m == true)
                        {
                            sAddMenuOn = false;
                            FMmenuOn = false;
                            selectEventMenuOn = false;
                            filterOn = false;
                            missionName = "";
                            missionNameTyped.setString(missionName);
                            FMcategory = "";
                            FMcategoryTyped.setString(FMcategory);
                            for(int i = 0; i < 5; i++)
                            {
                                FMdeadline[i] = "";
                                FMdeadlineTyped[i].setString(FMdeadline[i]);
                            }
                            for(int i = 0; i < 2; i++)
                            {
                                duration[i] = "";
                                maxContiDuration[i] = "";
                                durationTyped[i].setString(duration[i]);
                                maxContiDurationTyped[i].setString(maxContiDuration[i]);
                            }
                            priority = "";
                            priorityTyped.setString(priority);
                            missionNameBlockOn = false;
                            categoryBlockOn = false;
                            for(int i = 0; i < 5; i++)
                                deadlineBlockOn[i] = false;
                            for(int i = 0; i < 2; i++)
                                FMdurationBlockOn[i] = false;
                            for(int i = 0; i < 2; i++)
                                maxContiDurationBlockOn[i] = false;
                            priorityBlockOn = false;
                        }
                        else if(sAdd_m == false)
                        {
                            sAddMenuOn = false;
                            FEmenuOn = false;
                            selectEventMenuOn = false;
                            filterOn = false;
                            eventName = "";
                            eventNameTyped.setString(eventName);
                            FEcategory = "";
                            FEcategoryTyped.setString(FEcategory);
                            for(int i = 0; i < 5; i++)
                            {
                                FEstartTime[i] = "";
                                FEstartTimeTyped[i].setString(FEstartTime[i]);
                                FEendTime[i] = "";
                                FEendTimeTyped[i].setString(FEendTime[i]);
                            }
                            eventNameBlockOn = false;
                            FEcategoryBlockOn = false;
                            for(int i = 0; i < 5; i++)
                            {
                                FEstartTimeBlockOn[i] = false;
                                FEendTimeBlockOn[i] = false;
                            }
                        }
                    }
                }
                else
                    sCloseButton.setFillColor(sf::Color(162, 219, 214));
            }

            //invalid menu on///////////////////////////////////////////////////////////////////////////////
            if(invalidMenuOn == true)
            {
                if(closeButton.getPosition().x <= mousePosition.x && mousePosition.x <= (closeButton.getPosition().x + closeButton.getSize().x) && closeButton.getPosition().y <= mousePosition.y && mousePosition.y <= (closeButton.getPosition().y + closeButton.getSize().y))
                {
                    closeButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        invalidMenuOn = false;
                        if(invalidMenu_m == true)
                        {
                            FMmenuOn = true;
                            FEmenuOn = false;
                        }
                        else if(invalidMenu_m == false)
                        {
                            FEmenuOn = true;
                            FMmenuOn = false;
                        }
                    }
                }
                else
                    closeButton.setFillColor(sf::Color(162, 219, 214));

            }
            //flexible mission menu on///////////////////////////////////////////////////////////////////////
            if(FMmenuOn == true)
            {
               //mission name
                if(missionNameBlock.getPosition().x <= mousePosition.x && mousePosition.x <= (missionNameBlock.getPosition().x + missionNameBlock.getSize().x) && missionNameBlock.getPosition().y <= mousePosition.y && mousePosition.y <= (missionNameBlock.getPosition().y + missionNameBlock.getSize().y))
                {
                    missionNameBlock.setOutlineThickness(inCM(0.05));
                    missionNameBlock.setOutlineColor(sf::Color(0, 0, 0, 50));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        missionNameBlockOn = true;
                        categoryBlockOn = false;
                        for(int j = 0; j < 5; j++)
                            deadlineBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            FMdurationBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            maxContiDurationBlockOn[j] = false;
                        priorityBlockOn = false;
                    }
                }
                else
                    missionNameBlock.setOutlineThickness(0);

                //category
                if(categoryBlock.getPosition().x <= mousePosition.x && mousePosition.x <= (categoryBlock.getPosition().x + categoryBlock.getSize().x) && categoryBlock.getPosition().y <= mousePosition.y && mousePosition.y <= (categoryBlock.getPosition().y + categoryBlock.getSize().y))
                {
                    categoryBlock.setOutlineThickness(inCM(0.05));
                    categoryBlock.setOutlineColor(sf::Color(0, 0, 0, 50));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        categoryBlockOn = true;
                        missionNameBlockOn = false;
                        for(int j = 0; j < 5; j++)
                            deadlineBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            FMdurationBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            maxContiDurationBlockOn[j] = false;
                        priorityBlockOn = false;
                    }
                }
                else
                    categoryBlock.setOutlineThickness(0);

                //deadline
                for(int i = 0; i < 5; i++)
                {
                    if(deadlineBlock[i].getPosition().x <= mousePosition.x && mousePosition.x <= (deadlineBlock[i].getPosition().x + deadlineBlock[i].getSize().x) && deadlineBlock[i].getPosition().y <= mousePosition.y && mousePosition.y <= (deadlineBlock[i].getPosition().y + deadlineBlock[i].getSize().y))
                    {
                        deadlineBlock[i].setOutlineThickness(inCM(0.03));
                        deadlineBlock[i].setOutlineColor(sf::Color(0, 0, 0, 50));
                        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        {
                            for(int j = 0; j < 5; j++)
                                deadlineBlockOn[j] = false;
                            deadlineBlockOn[i] = true;
                            categoryBlockOn = false;
                            missionNameBlockOn = false;
                            for(int j = 0; j < 2; j++)
                                FMdurationBlockOn[j] = false;
                            for(int j = 0; j < 2; j++)
                                maxContiDurationBlockOn[j] = false;
                            priorityBlockOn = false;
                        }
                    }
                    else
                        deadlineBlock[i].setOutlineThickness(0);
                }

                //duration
                for(int i = 0; i < 2; i++)
                {
                    if(durationBlock[i].getPosition().x <= mousePosition.x && mousePosition.x <= (durationBlock[i].getPosition().x + durationBlock[i].getSize().x) && durationBlock[i].getPosition().y <= mousePosition.y && mousePosition.y <= (durationBlock[i].getPosition().y + durationBlock[i].getSize().y))
                    {
                        durationBlock[i].setOutlineThickness(inCM(0.03));
                        durationBlock[i].setOutlineColor(sf::Color(0, 0, 0, 50));
                        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        {
                            for(int j = 0; j < 2; j++)
                                FMdurationBlockOn[j] = false;
                            FMdurationBlockOn[i] = true;
                            missionNameBlockOn = false;
                            categoryBlockOn = false;
                            for(int j = 0; j < 5; j++)
                                deadlineBlockOn[j] = false;
                            for(int j = 0; j < 2; j++)
                                maxContiDurationBlockOn[j] = false;
                            priorityBlockOn = false;
                        }
                    }
                    else
                        durationBlock[i].setOutlineThickness(0);
                }

                //max continuous duration
                for(int i = 0; i < 2; i++)
                {
                    if(maxContiDurationBlock[i].getPosition().x <= mousePosition.x && mousePosition.x <= (maxContiDurationBlock[i].getPosition().x + maxContiDurationBlock[i].getSize().x) && maxContiDurationBlock[i].getPosition().y <= mousePosition.y && mousePosition.y <= (maxContiDurationBlock[i].getPosition().y + maxContiDurationBlock[i].getSize().y))
                    {
                        maxContiDurationBlock[i].setOutlineThickness(inCM(0.03));
                        maxContiDurationBlock[i].setOutlineColor(sf::Color(0, 0, 0, 50));
                        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        {
                            for(int j = 0; j < 2; j++)
                                maxContiDurationBlockOn[j] = false;
                            maxContiDurationBlockOn[i] = true;
                            missionNameBlockOn = false;
                            categoryBlockOn = false;
                            for(int j = 0; j < 5; j++)
                                deadlineBlockOn[j] = false;
                            for(int j = 0; j < 2; j++)
                                FMdurationBlockOn[j] = false;
                            priorityBlockOn = false;
                        }
                    }
                    else
                        maxContiDurationBlock[i].setOutlineThickness(0);
                }

                //priority
                if(priorityBlock.getPosition().x <= mousePosition.x && mousePosition.x <= (priorityBlock.getPosition().x + priorityBlock.getSize().x) && priorityBlock.getPosition().y <= mousePosition.y && mousePosition.y <= (priorityBlock.getPosition().y + priorityBlock.getSize().y))
                {
                    priorityBlock.setOutlineThickness(inCM(0.05));
                    priorityBlock.setOutlineColor(sf::Color(0, 0, 0, 50));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        priorityBlockOn = true;
                        missionNameBlockOn = false;
                        categoryBlockOn = false;
                        for(int j = 0; j < 5; j++)
                            deadlineBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            FMdurationBlockOn[j] = false;
                        for(int j = 0; j < 2; j++)
                            maxContiDurationBlockOn[j] = false;
                    }
                }
                else
                    priorityBlock.setOutlineThickness(0);

                //add
                if(FMaddButton.getPosition().x <= mousePosition.x && mousePosition.x <= (FMaddButton.getPosition().x + FMaddButton.getSize().x) && FMaddButton.getPosition().y <= mousePosition.y && mousePosition.y <= (FMaddButton.getPosition().y + FMaddButton.getSize().y))
                {
                    FMaddButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        bool invalid = false;
                        //check if invalid
                        if(missionName == "" || FMcategory == "" || priority == "")
                            invalid = true;
                        for(int i = 0; i < 5; i++)
                            if(FMdeadline[i] == "")
                                invalid = true;
                        for(int i = 0; i < 2; i++)
                            if(duration[i] == "" || maxContiDuration[i] == "")
                                invalid = true;
                        if(invalid == false)
                        {
                            int year = stoi(FMdeadline[0]);
                            int month = stoi(FMdeadline[1]);
                            int day = stoi(FMdeadline[2]);
                            int hour[3];
                            hour[0] = stoi(FMdeadline[3]);
                            hour[1] = stoi(duration[0]);
                            hour[2] = stoi(maxContiDuration[0]);
                            int minute[3];
                            minute[0] = stoi(FMdeadline[4]);
                            minute[1] = stoi(duration[1]);
                            minute[2] = stoi(maxContiDuration[1]);
                            int pri = stoi(priority);

                            NOW.Current();
                            if(!(year == 2018 || year == 2019) || year < NOW.getYear())
                                invalid = true;
                            if(!(1 <= month && month <= 12) || ( ( month < NOW.getMonth() ) && ( year == NOW.getYear() )))
                                invalid = true;
                            if(day < NOW.getDay() &&  ( month == NOW.getMonth() ) && ( year == NOW.getYear() ))
                                invalid = true;
                            if( ( hour[0] < NOW.getHour() ) && ( day == NOW.getDay() ) && ( month == NOW.getMonth() ) && ( year == NOW.getYear() ))
                                invalid = true;
                            if( ( minute[0] < NOW.getMinute() ) && ( hour[0] == NOW.getHour() ) && ( day == NOW.getDay() ) && ( month == NOW.getMonth() ) && ( year == NOW.getYear() ))
                                invalid = true;
                            switch(month)
                            {
                                case 1:
                                case 3:
                                case 5:
                                case 7:
                                case 8:
                                case 10:
                                case 12:
                                    if(!(1 <= day && day <= 31))
                                        invalid = true;
                                    break;
                                case 4:
                                case 6:
                                case 9:
                                case 11:
                                    if(!(1 <= day && day <= 30))
                                        invalid = true;
                                    break;
                                case 2:
                                    if(year % 4 != 0 && !(1 <= day && day <= 28))
                                        invalid = true;
                                    else if(year % 4 == 0 && !(1 <= day && day <= 29))
                                        invalid = true;
                            }
                            for(int i = 0; i < 3; i++)
                            {
                                if(i!=1)
                                {
                                    if(!(0 <= hour[i] && hour[i] <= 23))
                                        invalid = true;
                                }
                            }
                            for(int i = 0; i < 3; i++)
                                if(!(0 <= minute[i] && minute[i] <= 59))
                                    invalid = true;
                            if(!(1 <= pri && pri <= 10))
                                invalid = true;
                        }

                        if(invalid == true)
                        {
                            invalidMenuOn = true;
                            invalidMenu_m = true;
                            FMmenuOn = false;
                        }

                        //add FM
                        if(invalid == false)
                        {
                            string MissionName = missionName;
                            string Deadline;
                            for(int i=0;i<5;i++)
                            {
                                if(i==1 || i==2 || i==3 || i==4)
                                {
                                    if (FMdeadline[i].length()==1)
                                        FMdeadline[i].insert(0,"0");
                                }
                                Deadline += FMdeadline[i];
                            }

                            string category = missionName;
                            string graph = FMcategory;

                            cout << "DDL: " << Deadline << endl;

                            int Priority = stoi(priority);
                            double Duration = stoi(duration[0])*60 + stoi(duration[1]);
                            double thresh =  stoi(maxContiDuration[0])*60 + stoi(maxContiDuration[1]);
                            OurTime ddl(Deadline);

                            double parts = ceil(Duration/thresh);

                            for(int i=0;i<parts;i++)
                            {
                                Mission *a;
                                if(thresh < Duration)
                                    a = new Mission(MissionName,graph,category,i,parts,Priority,ddl,thresh);
                                else
                                    a = new Mission(MissionName,graph,category,i,parts,Priority,ddl,Duration);
                                MBag.Bag.add(a);
                                Duration -= thresh;
                            }
                            cout << "DDL: " << Deadline << endl;

                            OurTime doodle;
                            doodle.Current();
                            string cur = doodle.getTimeStr().substr(0,8);
                            int weekN,dayN;
                            for(int i=0;i<weeks;i++)
                            {
                                for(int j=0;j<aweek;j++)
                                {
                                    string hello = year2018[i][j]->getToday().substr(0,8);
                                    if(hello==cur)
                                    {
                                        weekN = i;
                                        dayN = j;
                                        break;
                                    }
                                    else
                                        continue;
                                }
                            }
//                            cout << "during deleting non fixed event" << endl;
                            for(int i=weekN;i<weeks;i++)
                            {
                                for(int j=dayN;j<aweek;j++)
                                {
                                    year2018[i][j]->deleteNonFixedEvent();
                                }
                            }
//                            cout << "ended deleting non fixed event" << endl;
                            for(int i=weekN;i<weeks;i++)
                            {
                                for(int j=dayN;j<aweek;j++)
                                {
                                    year2018[i][j]->showToday();
                                }
                            }
                            bool eventNotAbleToAdd = false;
                            for(int i=weekN;i<weeks;i++)
                            {
                                for(int j=dayN;j<aweek;j++)
                                {
        //                            cout << "i:" << i << " j: " << j << endl;
        //                            year2018[i][j]->unCheck();
                                    while(1)
                                    {
                                        int freeTime = year2018[i][j]->getDuration();
                                        OurTime timeP = year2018[i][j]->getFreeTime();
                                        if(freeTime==-1)
                                            break;

                                        MissionBag* chosen = KnapSack(MBag,freeTime);
                                        for(int i=0;i<chosen->Bag.get_itemCount();i++)
                                        {
                                            OurTime DDL(chosen->Bag[i]->GetMdeadline());
                                            if(timeP - DDL >0)
                                            {
                                                string name = chosen->Bag[i]->GetName();
                                                int ind = stoi(chosen->Bag[i]->GetMindex());
                                                int tCnt = stoi(chosen->Bag[i]->GetMtotalCnt());
                                                chosen->Bag.remove(name,ind,tCnt);
                                                MBag.Bag.remove(name,ind,tCnt);
                                                eventNotAbleToAdd = true;
                                            }
                                        }

        //                                cout <<"chosen item count: " <<  chosen->Bag.get_itemCount() << endl;
                                        Event** fillin = new Event*[chosen->Bag.get_itemCount()];
                                        for(int k=0;k<chosen->Bag.get_itemCount();k++)
                                        {
                                            fillin[k] = chosen->Bag[k];
                                        }
        //                                cout << "start filling Time" << endl;
                                        year2018[i][j]->fillTime(fillin,chosen->Bag.get_itemCount());
                                        year2018[i][j]->showToday();
        //                                cout << "done filling Time" << endl;
        //                                cout << "start updating Time" << endl;
                                        for(int k=0;k<chosen->Bag.get_itemCount();k++)
                                        {
                                            MBag.Bag.remove(fillin[k]->GetName(),stoi(fillin[k]->GetMindex()),stoi(fillin[k]->GetMtotalCnt()));
                                            MBag.Bag.add(fillin[k]);
                                        }
        //                                cout << "done updating MBag" << endl;

                                    }
                                    year2018[i][j]->unCheck();
                                }
                            }
                            if(eventNotAbleToAdd)
                                cout << "Not Enough Time To Schedule Your Missions\nTry To Spend Less Time on Sleeping or Eating" << endl;
                            MBag.Bag.printBag();

                            MBag.SaveFile(MissionLocation);

//                            cout << "DDL: " << Deadline << endl;


                            FMmenuOn = false;
                            sAddMenuOn = true;
                            sAdd_m = true;


                        }
                    }
                }
                else
                    FMaddButton.setFillColor(sf::Color(162, 219, 214));

                //cancel
                if(FMcancelButton.getPosition().x <= mousePosition.x && mousePosition.x <= (FMcancelButton.getPosition().x + FMcancelButton.getSize().x) && FMcancelButton.getPosition().y <= mousePosition.y && mousePosition.y <= (FMcancelButton.getPosition().y + FMcancelButton.getSize().y))
                {
                    FMcancelButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        selectEventMenuOn = true;
                        FMmenuOn = false;
                        missionNameBlockOn = false;
                        categoryBlockOn = false;
                        missionName = "";
                        missionNameTyped.setString(missionName);
                        FMcategory = "";
                        FMcategoryTyped.setString(FMcategory);
                        for(int i = 0; i < 5; i++)
                        {
                            deadlineBlockOn[i] = false;
                            FMdeadline[i] = "";
                            FMdeadlineTyped[i].setString(FMdeadline[i]);
                        }
                        for(int i = 0; i < 2; i++)
                        {
                            FMdurationBlockOn[i] = false;
                            duration[i] = "";
                            durationTyped[i].setString(duration[i]);
                            maxContiDurationBlockOn[i] = false;
                            maxContiDuration[i] = "";
                            maxContiDurationTyped[i].setString(maxContiDuration[i]);
                        }
                        priorityBlockOn = false;
                        priority = "";
                        priorityTyped.setString(priority);
                    }
                }
                else
                    FMcancelButton.setFillColor(sf::Color(162, 219, 214));
            }

            //fixed time event menu on
            if(FEmenuOn == true)
            {
                //event name
                if(eventNameBlock.getPosition().x <= mousePosition.x && mousePosition.x <= (eventNameBlock.getPosition().x + eventNameBlock.getSize().x) && eventNameBlock.getPosition().y <= mousePosition.y && mousePosition.y <= (eventNameBlock.getPosition().y + eventNameBlock.getSize().y))
                {
                    eventNameBlock.setOutlineThickness(inCM(0.05));
                    eventNameBlock.setOutlineColor(sf::Color(0, 0, 0, 50));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        eventNameBlockOn = true;
                        FEcategoryBlockOn = false;
                        for(int i = 0; i < 5; i++)
                            FEstartTimeBlockOn[i] = false;
                        for(int i = 0; i < 5; i++)
                            FEendTimeBlockOn[i] = false;
                    }
                }
                else
                    eventNameBlock.setOutlineThickness(0);

                //category
                if(FEcategoryBlock.getPosition().x <= mousePosition.x && mousePosition.x <= (FEcategoryBlock.getPosition().x + FEcategoryBlock.getSize().x) && FEcategoryBlock.getPosition().y <= mousePosition.y && mousePosition.y <= (FEcategoryBlock.getPosition().y + FEcategoryBlock.getSize().y))
                {
                    FEcategoryBlock.setOutlineThickness(inCM(0.05));
                    FEcategoryBlock.setOutlineColor(sf::Color(0, 0, 0, 50));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        FEcategoryBlockOn = true;
                        eventNameBlockOn = false;
                        for(int i = 0; i < 5; i++)
                            FEstartTimeBlockOn[i] = false;
                        for(int i = 0; i < 5; i++)
                            FEendTimeBlockOn[i] = false;
                    }
                }
                else
                    FEcategoryBlock.setOutlineThickness(0);

                //start time
                for(int i = 0; i < 5; i++)
                {
                    if(FEstartTimeBlock[i].getPosition().x <= mousePosition.x && mousePosition.x <= (FEstartTimeBlock[i].getPosition().x + FEstartTimeBlock[i].getSize().x) && FEstartTimeBlock[i].getPosition().y <= mousePosition.y && mousePosition.y <= (FEstartTimeBlock[i].getPosition().y + FEstartTimeBlock[i].getSize().y))
                    {
                        FEstartTimeBlock[i].setOutlineThickness(inCM(0.03));
                        FEstartTimeBlock[i].setOutlineColor(sf::Color(0, 0, 0, 50));
                        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        {
                            for(int i = 0; i < 5; i++)
                                FEstartTimeBlockOn[i] = false;
                            FEstartTimeBlockOn[i] = true;
                            FEcategoryBlockOn = false;
                            eventNameBlockOn = false;
                            for(int i = 0; i < 5; i++)
                                FEendTimeBlockOn[i] = false;
                        }
                    }
                    else
                        FEstartTimeBlock[i].setOutlineThickness(0);
                }

                //end time
                for(int i = 0; i < 5; i++)
                {
                    if(FEendTimeBlock[i].getPosition().x <= mousePosition.x && mousePosition.x <= (FEendTimeBlock[i].getPosition().x + FEendTimeBlock[i].getSize().x) && FEendTimeBlock[i].getPosition().y <= mousePosition.y && mousePosition.y <= (FEendTimeBlock[i].getPosition().y + FEendTimeBlock[i].getSize().y))
                    {
                        FEendTimeBlock[i].setOutlineThickness(inCM(0.03));
                        FEendTimeBlock[i].setOutlineColor(sf::Color(0, 0, 0, 50));
                        if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        {
                            for(int i = 0; i < 5; i++)
                                FEendTimeBlockOn[i] = false;
                            FEendTimeBlockOn[i] = true;
                            FEcategoryBlockOn = false;
                            eventNameBlockOn = false;
                            for(int i = 0; i < 5; i++)
                                FEstartTimeBlockOn[i] = false;
                        }
                    }
                    else
                        FEendTimeBlock[i].setOutlineThickness(0);
                }

                //add
                if(FEaddButton.getPosition().x <= mousePosition.x && mousePosition.x <= (FEaddButton.getPosition().x + FEaddButton.getSize().x) && FEaddButton.getPosition().y <= mousePosition.y && mousePosition.y <= (FEaddButton.getPosition().y + FEaddButton.getSize().y))
                {
                    FEaddButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        //check if invalid
                        bool invalid = false;
                        if(eventName == "" || FEcategory == "")
                            invalid = true;
                        for(int i = 0; i < 5; i++)
                            if(FEstartTime[i] == "" || FEendTime[i] == "")
                                invalid = true;
                        if(invalid == false)
                        {
                            int year[2] = {0, 0}, month[2] = {0, 0}, day[2] = {0, 0}, hour[2] = {0, 0}, minute[2] = {0, 0};
                            year[0] = stoi(FEstartTime[0]);
                            year[1] = stoi(FEendTime[0]);
                            month[0] = stoi(FEstartTime[1]);
                            month[1] = stoi(FEendTime[1]);
                            day[0] = stoi(FEstartTime[2]);
                            day[1] = stoi(FEendTime[2]);
                            hour[0] = stoi(FEstartTime[3]);
                            hour[1] = stoi(FEendTime[3]);
                            minute[0] = stoi(FEstartTime[4]);
                            minute[1] = stoi(FEendTime[4]);

                            for(int i = 0; i < 2; i++)
                            {
                                if(!(year[i] == 2018 || year[i] == 2019))
                                    invalid = true;
                                else if(!(1 <= month[i] && month[i] <= 12))
                                    invalid = true;
                                switch(month[i])
                                {
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                    case 8:
                                    case 10:
                                    case 12:
                                        if(!(1 <= day[i] && day[i] <= 31))
                                            invalid = true;
                                        break;
                                    case 4:
                                    case 6:
                                    case 9:
                                    case 11:
                                        if(!(1 <= day[i] && day[i] <= 30))
                                            invalid = true;
                                        break;
                                    case 2:
                                        if(year[i] % 4 != 0 && !(1 <= day[i] && day[i] <= 28))
                                            invalid = true;
                                        else if(year[i] % 4 == 0 && !(1 <= day[i] && day[i] <= 29))
                                            invalid = true;
                                }
                                if(!(0 <= hour[i] && hour[i] <= 23))
                                    invalid = true;
                                else if(!(0 <= minute[i] && minute[i] <= 59))
                                    invalid = true;
                            }
                            //end time before start time
                            if(year[0] > year[1])
                                invalid = true;
                            else if(year[0] == year[1])
                            {
                                if(month[0] > month[1])
                                    invalid = true;
                                else if(month[0] == month[1])
                                {
                                    if(day[0] > day[1])
                                        invalid = true;
                                    else if(day[0] == day[1])
                                    {
                                        if(hour[0] > hour[1])
                                            invalid = true;
                                        else if(hour[0] == hour[1])
                                        {
                                            if(minute[0] >= minute[1])
                                                invalid = true;
                                        }
                                    }
                                }
                            }
                        }
                        
                        if(invalid == true)
                        {
                            invalidMenuOn = true;
                            invalidMenu_m = false;
                            FEmenuOn = false;
                        }
                        
                        //add event
                        if(invalid == false)
                        {

                            string fixedEventName = eventName;
                            string startTime;
                            for(int i=0;i<5;i++)
                            {
                                if(i==1 || i==2 || i==3 || i==4)//month day hour min is one digit
                                {
                                    if(FEstartTime[i].length()==1)
                                        FEstartTime[i].insert(0,"0");
                                }
                                startTime += FEstartTime[i];
                            }
                            string endTime;
                            for(int i=0;i<5;i++)
                            {
                                if(i==1 || i==2 || i==3 || i==4)//month day hour min is one digit
                                {
                                    if(FEendTime[i].length()==1)
                                        FEendTime[i].insert(0,"0");
                                }
                                endTime += FEendTime[i];
                            }
                            string category = FEcategory;
                            int duration;

                            OurTime startT(startTime);


                            OurTime endT(endTime);

                            duration = endT - startT;
                            FixedEvent *one = new FixedEvent(fixedEventName,category,startT,endT,duration);
                            string moveto = startTime.substr(0,8);
                            for(int i=0;i<weeks;i++)
                            {
                                for(int j=0;j<aweek;j++)
                                {
                                    string TD = year2018[i][j]->getToday().substr(0,8);
                                    if(TD==moveto)
                                    {
                                        //is not occuppied
                                        if(year2018[i][j]->checkIsFree(one))
                                        {
                                            year2018[i][j]->addFixedEvent(one);
                                            FEBag.Bag.add(one);
                                            FEBag.SaveFile(FixedLocation);
                                            FEmenuOn = false;
                                            sAddMenuOn = true;
                                            sAdd_m = false;

                                        }
                                        //is occuppied
                                        else
                                        {
                                            delete one;
                                            invalid = true;
                                            invalidMenuOn = true;
                                            invalidMenu_m = false;
                                            FEmenuOn = false;
                                            sAddMenuOn = false;
                                            sAdd_m = false;
                                        }
//                                        cout << TD << endl;
                                    }

                                }
                            }
                            
                        }
                    }
                }
                else
                    FEaddButton.setFillColor(sf::Color(162, 219, 214));

                //cancel
                if(FEcancelButton.getPosition().x <= mousePosition.x && mousePosition.x <= (FEcancelButton.getPosition().x + FEcancelButton.getSize().x) && FEcancelButton.getPosition().y <= mousePosition.y && mousePosition.y <= (FEcancelButton.getPosition().y + FEcancelButton.getSize().y))
                {
                    FEcancelButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        selectEventMenuOn = true;
                        FEmenuOn = false;
                        eventNameBlockOn = false;
                        FEcategoryBlockOn = false;
                        eventName = "";
                        eventNameTyped.setString(eventName);
                        FEcategory = "";
                        FEcategoryTyped.setString(FEcategory);
                        for(int i = 0; i < 5; i++)
                        {
                            FEstartTimeBlockOn[i] = false;
                            FEendTimeBlockOn[i] = false;
                            FEstartTime[i] = "";
                            FEendTime[i] = "";
                            FEstartTimeTyped[i].setString(FEstartTime[i]);
                            FEendTimeTyped[i].setString(FEendTime[i]);
                        }
                    }
                }
                else
                    FEcancelButton.setFillColor(sf::Color(162, 219, 214));
            }


            //select event menu on//////////////////////////////////////////////////////////////////////////////
            if(selectEventMenuOn == true)
            {
                //flexible time mission
                if(FMbutton.getPosition().x <= mousePosition.x && mousePosition.x <= FMbutton.getPosition().x + FMbutton.getSize().x && FMbutton.getPosition().y <= mousePosition.y && mousePosition.y < FMbutton.getPosition().y + cancelButton.getSize().y)
                {
                    FMbutton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        FMmenuOn = true;
                        FEmenuOn = false;
                        selectEventMenuOn = false;
                    }
                }
                else
                    FMbutton.setFillColor(sf::Color(162, 219, 214));

                //fixed time event
                if(FEbutton.getPosition().x <= mousePosition.x && mousePosition.x <= FEbutton.getPosition().x + FEbutton.getSize().x && FEbutton.getPosition().y <= mousePosition.y && mousePosition.y < FEbutton.getPosition().y + cancelButton.getSize().y)
                {
                    FEbutton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        FEmenuOn = true;
                        FMmenuOn = false;
                        selectEventMenuOn = false;
                    }
                }
                else
                    FEbutton.setFillColor(sf::Color(162, 219, 214));

                //cancel
                if(cancelButton.getPosition().x <= mousePosition.x && mousePosition.x <= cancelButton.getPosition().x + cancelButton.getSize().x && cancelButton.getPosition().y <= mousePosition.y && mousePosition.y < cancelButton.getPosition().y + cancelButton.getSize().y)
                {
                    cancelButton.setFillColor(sf::Color(197, 233, 230));
                    if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                    {
                        filterOn = false;
                        selectEventMenuOn = false;
                    }
                }
                else
                    cancelButton.setFillColor(sf::Color(162, 219, 214));
            }

            /*PAGE3-----------------------------------------------------------*/
            if(page3)
            {
                List L = Merge_Bag2List(FEBag, MBag);
                //EVERY TIME DRAW RBAR AND STATIC FIRST
                DrawRBar(window, MBag, RBar_scale);
                DrawStatic(window,Bar2PieSW, RBar_scale);
                
                if(Bar2PieSW==0)//DRAW LBAR
                {
                    DrawBar(window, L, L.getCount(), w);
                    DrawBar(window, L, L.getCount(), m);
                    DrawBar(window, L, L.getCount(), y);
                    if(MouseOnBar(window, w))
                        ShowBarMes(window, L, w);
                    if(MouseOnBar(window, m))
                        ShowBarMes(window, L, m);
                    if(MouseOnBar(window, y))
                        ShowBarMes(window, L, y);
                    DrawBarTitle(window);
                }
                
                else if(Bar2PieSW==1)//DRAW PIE
                {
                    bool Explode=false;
                    if(MouseOnPie(window))
                    {
                        Explode  =true;
                        ShowPieMes(window, L, Pie_scale);
                    }
                    cout<<Pie_scale<<endl;
                    DrawPie(window, L, L.getCount(), Pie_scale, Explode);
                }
                
            }
            
            
            
            
            
            
            //add button/////////////////////////////////////////////////////////////////////////////////////
            float distanceToAdd_o = sqrt(pow(mousePosition.x - inCM(0.75), 2) + pow(mousePosition.y - inCM(9.5), 2));
            if(distanceToAdd_o <= inCM(0.75))
            {
                addButton.setOutlineThickness(15);
                addButton.setOutlineColor(sf::Color(255, 255, 255, 80));
                //button clicked
                if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                {
                    filterOn = true;
                    selectEventMenuOn = true;
                }
            }
            else
                addButton.setOutlineThickness(0);

            //schedule button/////////////////////////////////////////////////////////////////////////////
            if(distanceToAdd_o > inCM(0.75) && mousePosition.x < inCM(1.5) && mousePosition.y < inCM(9.5))
            {
                if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                {
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                    page2 = true;
                    page3 = false;
                }
                scheduleButton.setFillColor(sf::Color(116, 190, 202));
            }
            else
                scheduleButton.setFillColor(sf::Color(86, 175, 191));

            //dashboard button//////////////////////////////////////////////////////////////////////////////
            if(distanceToAdd_o > inCM(0.75) && mousePosition.x < inCM(1.5) && mousePosition.y > inCM(9.5))
            {
                if(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                {
                    while(sf::Mouse::isButtonPressed(sf::Mouse::Left))
                        ;
                    page3 = true;
                    page2 = false;
                }
                dashboardButton.setFillColor(sf::Color(13, 100, 179));
            }
            else
                dashboardButton.setFillColor(sf::Color(11, 83, 149));
            //left page button/////////////////////////////////////////////////////////////////////////////////
            float distanceToLeft_o = sqrt(pow(mousePosition.x - leftButton.getPosition().x - leftButton.getRadius(), 2) + pow(mousePosition.y - leftButton.getPosition().y - leftButton.getRadius(), 2));
            if(distanceToLeft_o < inCM(0.25))
                leftButton.setFillColor(sf::Color(185, 223, 229));
            else
                leftButton.setFillColor(sf::Color(86, 175, 191));
            //right page button////////////////////////////////////////////////////////////////////////////////
            float distanceToRight_o = sqrt(pow(mousePosition.x - rightButton.getPosition().x - rightButton.getRadius(), 2) + pow(mousePosition.y - rightButton.getPosition().y - rightButton.getRadius(), 2));
            if(distanceToRight_o < inCM(0.25))
                rightButton.setFillColor(sf::Color(185, 223, 229));
            else
                rightButton.setFillColor(sf::Color(86, 175, 191));

            //draw text and shapes///////////////////////////////////////////////////////////////////////////////
            window.draw(scheduleButton);
            window.draw(scheduleText);
            window.draw(dashboardButton);
            window.draw(dashboardText);
            if(page2)
            {
                for(int i = 0; i < 8; i++) //vertical line
                    window.draw(v_linePtr[i]);
                for(int i = 0; i < 5; i++) //horizontal line
                    window.draw(h_linePtr[i]);
                //Box Position information and amount
                TotalBoxes = MBag.Bag.getSize()+FEBag.Bag.getSize();
                BoxMes_Button_index=-1;
                //Draw all events boxes

                DrawCalenderBox(window,RS, MBag, FEBag, move_page);
                

                
                for(int i = 0; i < 5; i++) //time text
                    window.draw(time[i]);
                window.draw(leftButton);
                window.draw(rightButton);
                if(DisplayBox)//Display Box information
                {
                    NoOtherMesBox =false;
                    DrawBoxMes(window, RS, BoxMes_Button, MBag, FEBag, BoxIndex);
                }
                if(filterOn == true)
                    window.draw(filter);
            }
            window.draw(addButton);
            window.draw(h_plus);
            window.draw(v_plus);
            if(selectEventMenuOn == true)
            {
                window.draw(selectEventMenu);
                window.draw(selectEventMenuTitle);
                window.draw(FMbutton);
                window.draw(FMbuttonText);
                window.draw(FEbutton);
                window.draw(FEbuttonText);
                window.draw(cancelButton);
                window.draw(cancelButtonText);
            }
            if(FMmenuOn == true)
            {
                window.draw(FMmenu);
                window.draw(FMmenuTitle);
                window.draw(missionNameText);
                if(missionNameBlockOn == true)
                    missionNameBlock.setFillColor(sf::Color(200, 200, 200));
                else
                    missionNameBlock.setFillColor(sf::Color(217, 217, 217));
                window.draw(missionNameBlock);
                window.draw(categoryText);
                if(categoryBlockOn == true)
                    categoryBlock.setFillColor(sf::Color(200, 200, 200));
                else
                    categoryBlock.setFillColor(sf::Color(217, 217, 217));
                window.draw(categoryBlock);
                window.draw(deadlineText);
                for(int i = 0; i < 5; i++)
                {
                    if(deadlineBlockOn[i] == true)
                        deadlineBlock[i].setFillColor(sf::Color(200, 200, 200));
                    else
                        deadlineBlock[i].setFillColor(sf::Color(217, 217, 217));
                    window.draw(deadlineBlock[i]);
                }
                for(int i = 0; i < 5; i++)
                    if(!(deadlineBlockOn[i] == true || (deadlineBlockOn[i] == false && FMdeadline[i] != "")))
                        window.draw(deadlineBlockText[i]);
                window.draw(durationText);
                for(int i = 0; i < 2; i++)
                {
                    if(FMdurationBlockOn[i] == true)
                        durationBlock[i].setFillColor(sf::Color(200, 200, 200));
                    else
                        durationBlock[i].setFillColor(sf::Color(217, 217, 217));
                    window.draw(durationBlock[i]);
                }
                for(int i = 0; i < 2; i++)
                    if(!(FMdurationBlockOn[i] == true || (FMdurationBlockOn[i] == false && duration[i] != "")))
                        window.draw(durationBlockText[i]);
                window.draw(maxContiDurationText);
                for(int i = 0; i < 2; i++)
                {
                    if(maxContiDurationBlockOn[i] == true)
                        maxContiDurationBlock[i].setFillColor(sf::Color(200, 200, 200));
                    else
                        maxContiDurationBlock[i].setFillColor(sf::Color(217, 217, 217));
                    window.draw(maxContiDurationBlock[i]);
                }
                for(int i = 0; i < 2; i++)
                    if(!(maxContiDurationBlockOn[i] == true || (maxContiDurationBlockOn[i] == false && maxContiDuration[i] != "")))
                        window.draw(maxContiDurationBlockText[i]);
                window.draw(priorityText);
                if(priorityBlockOn == true)
                    priorityBlock.setFillColor(sf::Color(200, 200, 200));
                else
                    priorityBlock.setFillColor(sf::Color(217, 217, 217));
                window.draw(priorityBlock);
                if(!(priorityBlockOn == true || (priorityBlockOn == false && priority != "")))
                    window.draw(priorityBlockText);
                window.draw(FMaddButton);
                window.draw(FMaddButtonText);
                window.draw(FMcancelButton);
                window.draw(FMcancelButtonText);
                window.draw(missionNameTyped);
                window.draw(FMcategoryTyped);
                for(int i = 0; i < 5; i++)
                    window.draw(FMdeadlineTyped[i]);
                for(int i = 0; i < 2; i++)
                    window.draw(durationTyped[i]);
                for(int i = 0; i < 2; i++)
                    window.draw(maxContiDurationTyped[i]);
                window.draw(priorityTyped);
            }
            if(FEmenuOn == true)
            {
                window.draw(FEmenu);
                window.draw(FEmenuTitle);
                window.draw(eventNameText);
                if(eventNameBlockOn == true)
                    eventNameBlock.setFillColor(sf::Color(200, 200, 200));
                else
                    eventNameBlock.setFillColor(sf::Color(217, 217, 217));
                window.draw(eventNameBlock);
                window.draw(FEcategoryText);
                if(FEcategoryBlockOn == true)
                    FEcategoryBlock.setFillColor(sf::Color(200, 200, 200));
                else
                    FEcategoryBlock.setFillColor(sf::Color(217, 217, 217));
                window.draw(FEcategoryBlock);
                window.draw(FEstartTimeText);
                for(int i = 0; i < 5; i++)
                {
                    if(FEstartTimeBlockOn[i] == true)
                        FEstartTimeBlock[i].setFillColor(sf::Color(200, 200, 200));
                    else
                        FEstartTimeBlock[i].setFillColor(sf::Color(217, 217, 217));
                    window.draw(FEstartTimeBlock[i]);
                }
                for(int i = 0; i < 5; i++)
                    if(!(FEstartTimeBlockOn[i] == true || (FEstartTimeBlockOn[i] == false && FEstartTime[i].length() != 0)))
                        window.draw(FEstartTimeBlockText[i]);
                window.draw(FEendTimeText);
                for(int i = 0; i < 5; i++)
                {
                    if(FEendTimeBlockOn[i] == true)
                        FEendTimeBlock[i].setFillColor(sf::Color(200, 200, 200));
                    else
                        FEendTimeBlock[i].setFillColor(sf::Color(217, 217, 217));
                    window.draw(FEendTimeBlock[i]);
                }
                for(int i = 0; i < 5; i++)
                    if(!(FEendTimeBlockOn[i] == true || (FEendTimeBlockOn[i] == false && FEendTime[i].length() != 0)))
                        window.draw(FEendTimeBlockText[i]);
                window.draw(FEaddButton);
                window.draw(FEaddButtonText);
                window.draw(FEcancelButton);
                window.draw(FEcancelButtonText);
                window.draw(eventNameTyped);
                window.draw(FEcategoryTyped);
                for(int i = 0; i < 5; i++)
                    window.draw(FEstartTimeTyped[i]);
                for(int i = 0; i < 5; i++)
                    window.draw(FEendTimeTyped[i]);
            }
            if(invalidMenuOn == true)
            {
                window.draw(invalidFilter);
                window.draw(invalidMenu);
                window.draw(invalidText);
                window.draw(closeButton);
                window.draw(closeButtonText);

            }
            if(sAddMenuOn == true)
            {
                window.draw(sAddMenu);
                window.draw(sAddText);
                window.draw(sCloseButton);
                window.draw(sCloseButtonText);
            }
            if(tooFullMenuOn == true)
            {
                window.draw(tooFullFilter);
                window.draw(tooFullMenu);
                window.draw(tooFullText);
                window.draw(tCloseButton);
                window.draw(tCloseButtonText);
            }
        }
        window.display();


    }
    window.clear();



    system("pause");

    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            year2018[i][j] = new Day(start);
            start = start + 1440;
        }
    }
    for(int i=0;i<aweek;i++)
    {
        week[i] = new Day(today);
        today = today +1440;
    }
//    cout << "done initializing year2018" << endl;
//    cout << "going into adding FE into year2018" << endl;
    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            for(int k=0;k<FEBag.Bag.get_itemCount();k++)
            {
                string FEtime = FEBag.Bag[k]->GetstartTime().substr(0,8);
                string cur = year2018[i][j]->getToday().substr(0,8);
                if(FEtime==cur)
                    year2018[i][j]->addFixedEvent(FEBag.Bag[k]);
                else
                    continue;
            }
//            year2018[i][j]->showToday();
        }
    }
//    cout << "finish adding FE into year2018" << endl;
//    cout << "start adding mission into year2018" << endl;
    for(int i=0;i<weeks;i++)
    {
        for(int j=0;j<aweek;j++)
        {
            for(int k=0;k<MBag.Bag.get_itemCount();k++)
            {
                string Mtime = MBag.Bag[k]->GetstartTime().substr(0,8);
                string cur = year2018[i][j]->getToday().substr(0,8);
                if(Mtime==cur)
                    year2018[i][j]->RestoreMission(MBag.Bag[k]);
                else
                    continue;
            }
//            year2018[i][j]->showToday();

        }
    }
//    cout << "finish adding Mission into year2018" << endl;
    for(int i=0;i<FEBag.Bag.get_itemCount();i++)
    {
        week[0]->addFixedEvent(FEBag.Bag[i]);
    }
    for(int i=0;i<MBag.Bag.get_itemCount();i++)
    {
        week[0]->RestoreMission(MBag.Bag[i]);
    }
    
    
    while(0)
    {
        
    cout << "press 1 for showing the view eventlist" << endl;
    cout << "press 4 for showing the dash board" << endl;

    cout << "press 0 for exit" << endl;

    oper = 0;
    cin >> oper;
    cin.ignore();


    //201804231934
/*

    Initialize an linklist of week pointer like 52 week
    With each of it being a pointer pointing to 7 days (an array)
    I have to initalize everyday and restart


    readin the event txt that includes info
    new mission or fixed event txt according to the infor
    ptr to the item i just create

    get start time and put it into the day


    Offline method would be right before closing

    mission name cannot be the same
*/









//                    view past calendar
//                        display the past calendar

    if(oper==1)
    {

        /*
        view list should be able to display past and current and future
        First display current week


        We should be able to display what is in a day with view point of a week
        on a certain time period
        e.g.
        2018/06/01
            Study Calculus xx hour yy minute from 9:00 to 11:00
            Play hoverboard xx hour yy minute from 20:00 to 23:05
        2018/06/02
            ... and so on
        The schedule here should be able to display in chronological order
        */
            cout << "press 1 for viewing what happened today" << endl;
            cout << "press 2 for adding a new Fixed event / Mission" << endl;
            cout << "press 3 for finishing a mission" << endl;
            cout << "press 4 for deleting a fixed event / Mission" << endl;
            cin >> oper;
            cin.ignore();
            if(oper == 2)
            {
                /*
                Rule of thumbs to keep in mind:
                1. We do not determine whether the mission needs more time or not
                2. Once the event within three days have been made, no further changes should be made.
                2-1 Unless it is significantly import and of great urgency
                2-2 If we encounter running out of time, let the user decide what he/she should do either
                    1. sleep less
                    2. Abandon unimportant missions


                First, we require the uncompleted mission sorted list to give us a bag of mission.
                From the bag of mission we can
                */
                cout << "press 1 for adding a fixed event" << endl;
                cout << "press 2 for adding a flexible mission" << endl;
                cin >> oper;
                cin.ignore();
                if(oper==1)
                {
                    string fixedEventName;
                    string startTime;
                    string endTime;
                    string category;
                    int duration;

                    cout << "Please type fixedEventName" << endl;
                    getline(cin,fixedEventName);

                    cout << "Please type startTime in the form of: \n201806301125 " << endl;
                    getline(cin,startTime);

                    OurTime startT(startTime);

                    cout << "end Time please keep this event in the same day" << endl;
                    getline(cin,endTime);

                    cout << "category" << endl;
                    getline(cin,category);
                    cout << category;

                    OurTime endT(endTime);
                    duration = endT - startT;
                    FixedEvent *one = new FixedEvent(fixedEventName,category,startT,endT,duration);
                    string moveto = startTime.substr(0,8);
                    for(int i=0;i<weeks;i++)
                    {
                        for(int j=0;j<aweek;j++)
                        {
                            string TD = year2018[i][j]->getToday().substr(0,8);
                            if(TD==moveto)
                            {
                                year2018[i][j]->addFixedEvent(one);
                                cout << TD << endl;
                            }

                        }
                    }
                    FEBag.Bag.add(one);
                    FEBag.SaveFile(FixedLocation);

                    /*
                    Now we would have a fixed event
                    We need just passing the event into the Day class
                    The Day class might need some function to help making the time occupied by fixed event be unavailable to use

                    */
                }
                else if(oper==2)
                {
                    string MissionName;
                    string Deadline;
                    string StartTime;
                    string category;
                    string graph;
                    int priority;
                    double duration;
                    double thresh;
                    cout << "Please type mission Name" << endl;
                    getline(cin,MissionName);
                    //    total time to complete the mission
                    cout << "Enter how long will you need to finish it (in minute) " << endl;
                    cin >> duration;


                    cout << "Maximum continuous minutes" << endl;
                    cin >> thresh;
                    cin.ignore();

                    cout << "DeadLine?" << endl;
                    getline(cin,Deadline);

                    OurTime ddl(Deadline);

                    double parts = ceil(duration/thresh);
                    cout << "please type in priority\nwith least important:1 to utmost important:10" << endl;
                    cin >> priority;
                    cin.ignore();

                    cout << "which type do you want this to graph???" << endl;
                    getline(cin,graph);

                    cout << "category" << endl;
                    getline(cin,category);

                    for(int i=0;i<parts;i++)
                    {
                        Mission *a;
                        if(thresh < duration)
                            a = new Mission(MissionName,graph,category,i,parts,priority,ddl,thresh);
                        else
                            a = new Mission(MissionName,graph,category,i,parts,priority,ddl,duration);
                        MBag.Bag.add(a);
                        duration -= thresh;
                    }

                    OurTime doodle;
                    doodle.Current();
                    string cur = doodle.getTimeStr().substr(0,8);
                    int weekN,dayN;
                    for(int i=0;i<weeks;i++)
                    {
                        for(int j=0;j<aweek;j++)
                        {
                            string hello = year2018[i][j]->getToday().substr(0,8);
                            if(hello==cur)
                            {
                                weekN = i;
                                dayN = j;
                                break;
                            }
                            else
                                continue;
                        }
                    }
                    cout << "during deleting non fixed event" << endl;
                    for(int i=weekN;i<weeks;i++)
                    {
                        for(int j=dayN;j<aweek;j++)
                        {
                            year2018[i][j]->deleteNonFixedEvent();
                        }
                    }
                    cout << "ended deleting non fixed event" << endl;
                    for(int i=weekN;i<weeks;i++)
                    {
                        for(int j=dayN;j<aweek;j++)
                        {
                            year2018[i][j]->showToday();
                        }
                    }
                    bool eventNotAbleToAdd = false;
                    for(int i=weekN;i<weeks;i++)
                    {
                        for(int j=dayN;j<aweek;j++)
                        {
//                            cout << "i:" << i << " j: " << j << endl;
//                            year2018[i][j]->unCheck();
                            while(1)
                            {
                                int freeTime = year2018[i][j]->getDuration();
                                OurTime timeP = year2018[i][j]->getFreeTime();
                                if(freeTime==-1)
                                    break;

                                MissionBag* chosen = KnapSack(MBag,freeTime);
                                for(int i=0;i<chosen->Bag.get_itemCount();i++)
                                {
                                    OurTime DDL(chosen->Bag[i]->GetMdeadline());
                                    if(timeP - DDL >0)
                                    {
                                        string name = chosen->Bag[i]->GetName();
                                        int ind = stoi(chosen->Bag[i]->GetMindex());
                                        int tCnt = stoi(chosen->Bag[i]->GetMtotalCnt());
                                        chosen->Bag.remove(name,ind,tCnt);
                                        MBag.Bag.remove(name,ind,tCnt);
                                        eventNotAbleToAdd = true;
                                    }
                                }

//                                cout <<"chosen item count: " <<  chosen->Bag.get_itemCount() << endl;
                                Event** fillin = new Event*[chosen->Bag.get_itemCount()];
                                for(int k=0;k<chosen->Bag.get_itemCount();k++)
                                {
                                    fillin[k] = chosen->Bag[k];
                                }
//                                cout << "start filling Time" << endl;
                                year2018[i][j]->fillTime(fillin,chosen->Bag.get_itemCount());
                                year2018[i][j]->showToday();
//                                cout << "done filling Time" << endl;
//                                cout << "start updating Time" << endl;
                                for(int k=0;k<chosen->Bag.get_itemCount();k++)
                                {
                                    MBag.Bag.remove(fillin[k]->GetName(),stoi(fillin[k]->GetMindex()),stoi(fillin[k]->GetMtotalCnt()));
                                    MBag.Bag.add(fillin[k]);
                                }
//                                cout << "done updating MBag" << endl;

                            }
                            year2018[i][j]->unCheck();
                        }
                    }
                    if(eventNotAbleToAdd)
                        cout << "Not Enough Time To Schedule Your Missions\nTry To Spend Less Time on Sleeping or Eating" << endl;
                    MBag.Bag.printBag();

                    MBag.SaveFile(MissionLocation);

                    /*
                        When I finish creating a or multiple series of mission
                        I need to put it into the mission bag
                        after that give it to knapsack and then it would return to me an array
                        after that

                        Now that I can create a new flexible mission variable.
                        We need to gain the access of the Uncompleted mission list
                        We pass the list into
                        Acquire how much time is available in a single day.
                        Pass that amount, and the uncompleted mission list into the knapsack algorithm
                        The algorithm should return an array containing
                            1. Mission name
                            2. Mission duration
                        That array would be passed into the day class and be inserted.
                    */
                }
                else
                    cout << "Enter something that is readable FOOL!!" << endl;
                        /*
                            add a mission event
                                clear out all the mission
                                add a new mission
                                recalculate
                                put it back into the day list
                            add a fixed event
                                if there is an overlapping
                                    not allowed

                                clear out al the mission
                                insert fixed event
                                recalculate and then insert

                            viewing style would be weekly
                        */
            }
            else if (oper == 1)
            {
                OurTime sony;
                sony.Current();
                string cur = sony.getTimeStr().substr(0,8);
                for(int i=0;i<weeks;i++)
                {
                    for(int j=0;j<aweek;j++)
                    {
                        string hello = year2018[i][j]->getToday().substr(0,8);
                        if(hello==cur)
                        {
                            year2018[i][j]->showToday();
                            break;
                        }
                        else
                            continue;
                    }
                }
            }
            else if (oper == 3)
            {
                for(int i=0;i<weeks;i++)
                {
                    for(int j=0;j<aweek;j++)
                        year2018[i][j]->showToday();
                }
                cout << "enter event date" << endl;
                cout << "e.g. 20180720" << endl;
                string date;
                cin >> date;
                cout << "enter mission name within that day" << endl;
                int weekN,dayN;
                for(int i=0;i<weeks;i++)
                {
                    for(int j=0;j<aweek;j++)
                    {
                        string hello = year2018[i][j]->getToday().substr(0,8);
                        if(hello==date)
                        {
                            year2018[i][j]->showToday();
                            weekN = i;
                            dayN = j;
                            break;
                        }
                        else
                            continue;
                    }
                }
                string missionName;
                cin.ignore();
                getline(cin,missionName);
                cout << "enter which part of the mission" << endl;
                int parr = 0;
                cin >> parr;
                cin.ignore();
                year2018[weekN][dayN]->deleteSpecificEvent(missionName,parr,true);
                MBag.SaveFile(MissionLocation);
            }
            else if (oper == 4)
            {
                for(int i=0;i<weeks;i++)
                {
                    for(int j=0;j<aweek;j++)
                        year2018[i][j]->showToday();
                }
                cout << "enter event date" << endl;
                cout << "e.g. 20180720" << endl;
                string date;
                cin >> date;
                cout << "enter mission / Fixed event name within that day" << endl;
                int weekN,dayN;
                for(int i=0;i<weeks;i++)
                {
                    for(int j=0;j<aweek;j++)
                    {
                        string hello = year2018[i][j]->getToday().substr(0,8);
                        if(hello==date)
                        {
                            year2018[i][j]->showToday();
                            weekN = i;
                            dayN = j;
                            break;
                        }
                        else
                            continue;
                    }
                }
                cout << "press 1 to delete mission" << endl;
                cout << "press 2 to delete Fixed Event" << endl;
                int FEorM=0;
                cin >> FEorM;
                if(FEorM==1)
                {
                    cout << "enter mission name within that day" << endl;
                    string missionName;
                    cin.ignore();
                    getline(cin,missionName);
                    cout << "enter which part of the mission" << endl;
                    int parr = 0;
                    cin >> parr;
                    year2018[weekN][dayN]->deleteSpecificEvent(missionName,parr,false);
                    MBag.SaveFile(MissionLocation);
                }
                else
                {
                    cout << "enter Fixed event name within that day" << endl;
                    string FixedName;
                    cin.ignore();
                    getline(cin,FixedName);
                    year2018[weekN][dayN]->deleteSpecificEvent(FixedName,-1,false);
                    FEBag.Bag.remove(FixedName);
                    FEBag.SaveFile(FixedLocation);
                }
            }
    }
    else if(oper==0)
    {
        return 0;
    }
    else if(oper==3)
    {
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<aweek;j++)
                year2018[i][j]->showToday();
        }
    }
    else if(oper==4)
    {
        /*
        We should be able to display a list showing the total amount of time contributed to each tag
        We may need some for loops to add up all of the time we used in the past week.
        Showing in the form of:
            Studying 5 hr 42 min ->20%
            Riding fixed gear 20 hr 30 min ->50%
            Facebook 3 hr 20 min ->30%
        */
    }
    else
        cout << "Enter something that is readable FOOL!!" << endl;
    }

    return 0;
}



/*------------------------------------------------------PAGE 3-------------------------------------------------------------------*/


/*---------------------------------------CHECK TIME SCALE FOR RIGHT BAR CHART-----------------------------------------*/
bool isThisWeek(Event* Mission)
{
    NOW.Current();
    OurTime Default("201807080000");
    OurTime MissionTime = Mission->getStartTime();
    
    int Now_MinuGap = NOW - Default;
    int Now_DayGap = round(Now_MinuGap);
    
    int Now_Week_Day = (Now_DayGap)%7;
    //1: Mon; 2: Tue; ... 6: Sat; 0: Sun
    
    int Mission_MinuGap = MissionTime - Default;
    int Mission_DayGap = round(Mission_MinuGap);
    if(Now_Week_Day==0)//Sunday
    {
        return ((Now_DayGap-Mission_DayGap)<7);
    }
    else if(Now_Week_Day==1)//monday
    {
        return ((Mission_DayGap-Now_DayGap)<7);
    }
    else if(Now_Week_Day==2)//Tue
    {
        return (abs(Mission_DayGap-Now_DayGap)<2 || (Mission_DayGap-Now_DayGap)<6);
    }
    else if(Now_Week_Day==3)//Wed
    {
        return (abs(Mission_DayGap-Now_DayGap)<3 || (Mission_DayGap-Now_DayGap)<5);
    }
    else if(Now_Week_Day==4)//Thurs
    {
        return (abs(Mission_DayGap-Now_DayGap)<4);
    }
    else if(Now_Week_Day==5)//Fri
    {
        return (abs(Mission_DayGap-Now_DayGap)<3 || (Now_DayGap-Mission_DayGap)<6);
    }
    else//Sat
    {
        return (abs(Mission_DayGap-Now_DayGap)<2 || (Now_DayGap-Mission_DayGap)<5);
    }
    
}
bool isThisMonth(Event* Mission)
{
    NOW.Current();
    string Now_Month = to_string(NOW.getMonth());
    if(Now_Month.length()==1)
        Now_Month.insert(0,"0");
    string MissionTime = Mission->GetstartTime();
    //201807080000
    if(Now_Month==MissionTime.substr(4,2))
        return true;
    else
        return false;
}

bool isThisYear(Event* Mission)
{
    NOW.Current();
    string Now_Year = to_string(NOW.getYear());
    string MissionTime = Mission->GetstartTime();
    //201807080000
    if(Now_Year==MissionTime.substr(0,4))
        return true;
    else
        return false;
}
bool isPast7Days(Event* Mission)
{
    NOW.Current();
    OurTime Default("201807080000");
    OurTime MissionTime = Mission->getStartTime();
    
    int Now_MinuGap = NOW - Default;
    int Now_DayGap = round(Now_MinuGap);
    int Mission_MinuGap = MissionTime - Default;
    int Mission_DayGap = round(Mission_MinuGap);
    return ((Now_DayGap-Mission_DayGap)<7 && (Now_DayGap-Mission_DayGap)>=0);
}

bool isPast4Weeks(Event* Mission)
{
    NOW.Current();
    OurTime Default("201807080000");
    OurTime MissionTime = Mission->getStartTime();
    
    int Now_MinuGap = NOW - Default;
    int Now_DayGap = round(Now_MinuGap);
    int Mission_MinuGap = MissionTime - Default;
    int Mission_DayGap = round(Mission_MinuGap);
    
    return ((Now_DayGap-Mission_DayGap)<29 && (Now_DayGap-Mission_DayGap)>=0);
}

int getWhichDay(Event* Mission)
{
    NOW.Current();
    OurTime Default("201807080000");
    OurTime MissionTime = Mission->getStartTime();
    
    int Now_MinuGap = NOW - Default;
    int Mission_MinuGap = MissionTime - Default;
    
    int Now_DayGap = round(Now_MinuGap);
    int Mission_DayGap = round(Mission_MinuGap);
    //    cout<<"MissionTime "<<MissionTime<<endl;
    //    cout<<"Now_DayGap "<<Now_DayGap<<endl;
    //    cout<<"Mission_DayGap "<<Mission_DayGap<<endl;
    
    return ((Now_DayGap-Mission_DayGap)>0 ? 6-Now_DayGap+Mission_DayGap:-1);
}

int getWhichWeek(Event* Mission)
{
    NOW.Current();
    OurTime Default("201807080000");
    OurTime MissionTime = Mission->getStartTime();
    
    int Now_MinuGap = NOW - Default;
    int Now_DayGap = round(Now_MinuGap);
    int Mission_MinuGap = MissionTime - Default;
    int Mission_DayGap = round(Mission_MinuGap);
    int Day_Gap = Now_DayGap - Mission_DayGap;
    if(Day_Gap==28)
        return 3;
    return (3- Day_Gap/7);
}

/*-----------------------------------------------CHECK MOUSE FUNCTIONS------------------------------------------------*/

bool MouseOnBar(sf::RenderWindow& wn, const string& Scale)
{
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    if(Scale=="W")
        return (x>=Bar_Week_Pos_X_Start && x<=Bar_Week_Pos_X_Start+Bar_Week_Pos_X_Gap && y>=Bar_Week_Pos_Y-thickness/2 && y<=Bar_Week_Pos_Y+thickness/2);
    else if(Scale=="M")
        return (x>=Bar_Month_Pos_X_Start && x<=Bar_Month_Pos_X_Start+Bar_Month_Pos_X_Gap && y>=Bar_Month_Pos_Y-thickness/2 && y<=Bar_Month_Pos_Y+thickness/2);
    else
        return (x>=Bar_Year_Pos_X_Start && x<=Bar_Year_Pos_X_Start+Bar_Year_Pos_X_Gap && y>=Bar_Year_Pos_Y-thickness/2 && y<=Bar_Year_Pos_Y+thickness/2);
}

bool MouseOnPie(sf::RenderWindow& wn)
{
    float Pie_Cen_x = 500, Pie_Cen_y =550;
    float Radius = 170;
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    return (x>=Pie_Cen_x-Radius && x<=Pie_Cen_x+Radius && y>=Pie_Cen_y-Radius && y<=Pie_Cen_y+Radius);
}

bool MouseOnBarSW(sf::RenderWindow& wn)
{
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    return (x>=Button_x_Start && x<=Button_x_End && y>=Button_y_Start && y<=Button_y_End);
}
bool MouseOnPieSW(sf::RenderWindow& wn)
{
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    return (x>=Button_x_End && x<=Button_x_End+Button_x_Gap && y>=Button_y_Start && y<=Button_y_End);
}
bool MouseOnPieScale(sf::RenderWindow& wn, const string& Scale)
{
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    if(Scale=="W")
        return (x>=Pge3_toPx(2.65) && x<=Pge3_toPx(2.65)+Button_x_Gap && y>= Pge3_toPx(9)&& y<=Pge3_toPx(9)+Button_y_Gap);
    else if(Scale=="M")
        return (x>=Pge3_toPx(2.65) && x<=Pge3_toPx(2.65)+Button_x_Gap && y>= Pge3_toPx(10.8)&& y<=Pge3_toPx(10.8)+Button_y_Gap);
    else
        return (x>=Pge3_toPx(2.65) && x<=Pge3_toPx(2.65)+Button_x_Gap && y>= Pge3_toPx(12.7)&& y<=Pge3_toPx(12.7)+Button_y_Gap);
}

bool MouseOnLBarSW(sf::RenderWindow& wn, const string& Scale)
{
    float x = sf::Mouse::getPosition(wn).x;
    float y = sf::Mouse::getPosition(wn).y;
    if(Scale=="D")
        return (x>=Pge3_toPx(22.6) && x<=Pge3_toPx(22.6)+Pge3_toPx(3.3) && y>=Button_y_Start && y<= Button_y_Start+Pge3_toPx(0.96));
    else
        return (x>=Pge3_toPx(26.1) && x<=Pge3_toPx(26.1)+Pge3_toPx(3.7) && y>=Button_y_Start && y<= Button_y_Start+Pge3_toPx(0.96));
}


/*---------------------------------SIDE FUNCTIONS FOR DRAWING -------------------------------------*/


void Choose_Color(float& Red, float& Green, float& Blue, string& Scale)
{
    if(Scale=="W")
    {
        Red = ::Bar_Week_Red_Start;
        Green = ::Bar_Week_Green_Start;
        Blue = ::Bar_Week_Blue_Start;
    }
    else if(Scale=="M")
    {
        Red = ::Bar_Month_Red_Start;
        Green = ::Bar_Month_Green_Start;
        Blue = ::Bar_Month_Blue_Start;
    }
    else if(Scale=="Y")
    {
        Red = ::Bar_Year_Red_Start;
        Green = ::Bar_Year_Green_Start;
        Blue = ::Bar_Year_Blue_Start;
    }
}
/*---------------------------------MESSEGE BOX-------------------------------------*/
void ShowBarMes(sf::RenderWindow& wn, List& lis, const string& Scale)
{
    //DRAW THE SUMMARIZED MESSEGEBOX
    sf::RectangleShape rectangle;
    float Mes_pos_x = 870, Mes_pos_y=0;
    float Mes_x_len = 230, Mes_y_len=270+Pge3_toPx(1.);
    if(Scale=="W")
    {
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
        Mes_pos_y = Bar_Week_Pos_Y-(Mes_y_len/1.4);
    }
    else if(Scale=="M")
    {
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
        Mes_pos_y = Bar_Month_Pos_Y-(Mes_y_len/1.4);
    }
    else
    {
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
        Mes_pos_y = Bar_Year_Pos_Y-(Mes_y_len/1.4);
    }
    rectangle.setPosition(Mes_pos_x, Mes_pos_y);
    rectangle.setSize(sf::Vector2f(Mes_x_len, Mes_y_len));
    
    //FILL IN THE TEXTES ONLY TOP 5
    sf::Text* Summarize = new sf::Text[lis.getCount()];
    
    float Font_x_pos = Mes_pos_x+10, Font_y_pos = Mes_pos_y+10;
    int amount=lis.getCount();
    int amount_c = amount;
    if(lis.getCount()>5)
        amount_c = 6;
    float Sum = 0;
    for (int i=0; i<lis.getCount(); i++)
        Sum+=lis[i]->value;
    float moreSpace=0;
    for(int i=0; i<amount_c; i++)
    {
        Summarize[i].setFont(font);
        Summarize[i].setCharacterSize(font_resize(25));
        Summarize[i].setFillColor(sf::Color(86, 175, 191));
        Summarize[i].setStyle(sf::Text::Bold );
        string number;
        string percentage;
        if(i==5)
        {
            float sum=0;
            for(int i=5; i<amount; i++)
                sum += (lis[i]->value);
            number = to_string((sum/Sum)*100);
            number = number.substr(0,number.find(".")+2);
            percentage  =number+"% Other";
        }
        else
        {
            number = to_string((lis[i]->value/Sum)*100);
            number = number.substr(0,number.find(".")+2);
            percentage = number+"% "+lis[i]->key;
        }
        
        if(number.length()==1)
            percentage.insert(0, "  ");
        Summarize[i].setString(percentage) ;
        
        float size =Summarize[i].getLocalBounds().width;
        float moreSpacePerwidth = 150.0/260;
        //CHECK IF IT NEEDS MORE SPACE
        if(size > moreSpacePerwidth*398)
        {
            moreSpace = size - moreSpacePerwidth*350;
            if(moreSpace>250)
                system("pause");
        }
        
        Summarize[i].setPosition({Font_x_pos, Font_y_pos});
        Font_y_pos+=50;
    }
    rectangle.setSize(sf::Vector2f(Mes_x_len+moreSpace, Mes_y_len));
    wn.draw(rectangle);
    for(int i=0; i<amount; i++)
        wn.draw(Summarize[i]);
    delete [] Summarize;
}

void ShowPieMes(sf::RenderWindow& wn, List& lis, const string& Scale)
{
    //DRAW THE SUMMARIZED MESSEGEBOX
    sf::RectangleShape rectangle;
    float Mes_pos_x = Pge3_toPx(15.3), Mes_pos_y=Pge3_toPx(8.29);
    float Mes_x_len = 230, Mes_y_len=270+Pge3_toPx(1.);
    if(Scale=="W")
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
    else if(Scale=="M")
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
    else
        rectangle.setFillColor(sf::Color(255, 255, 255, 240.0));
    rectangle.setPosition(Mes_pos_x, Mes_pos_y);
    rectangle.setSize(sf::Vector2f(Mes_x_len, Mes_y_len));
    
    //FILL IN THE TEXTES ONLY TOP 5
    sf::Text* Summarize = new sf::Text[lis.getCount()];
    
    float Font_x_pos = Mes_pos_x+10, Font_y_pos = Mes_pos_y+10;
    
    int amount=lis.getCount();
    int amount_c =amount;
    if(lis.getCount()>5)
        amount_c = 6;
    float Sum = 0;
    for (int i=0; i<lis.getCount(); i++)
        Sum+=lis[i]->value;
    float moreSpace=0;
    for(int i=0; i<amount_c; i++)
    {
        Summarize[i].setFont(font);
        Summarize[i].setCharacterSize(font_resize(25));
        Summarize[i].setFillColor(sf::Color(86, 175, 191));
        Summarize[i].setStyle(sf::Text::Bold);
        
        string number;
        string percentage;
        if(i==5)
        {
            float sum=0;
            for(int i=5; i<amount; i++)
                sum += (lis[i]->value);
            number = to_string((sum/Sum)*100);
            number = number.substr(0,number.find(".")+2);
            percentage  =number+"% Other";
        }
        else
        {
            number = to_string((lis[i]->value/Sum)*100);
            number = number.substr(0,number.find(".")+2);
            percentage = number+"% "+lis[i]->key;
        }
        
        Summarize[i].setString(percentage);
        float size =Summarize[i].getLocalBounds().width;
        float moreSpacePerwidth = 150.0/260;
        //CHECK IF IT NEEDS MORE SPACE
        if(size > moreSpacePerwidth*398)
        {
            moreSpace = size - moreSpacePerwidth*350;
            if(moreSpace>250)
                system("pause");
        }
        
        Summarize[i].setPosition({Font_x_pos, Font_y_pos});
        Font_y_pos+=50;
    }
    rectangle.setSize(sf::Vector2f(Mes_x_len+moreSpace, Mes_y_len));
    wn.draw(rectangle);
    for(int i=0; i<amount; i++)
        wn.draw(Summarize[i]);
    delete [] Summarize;
}

/*-----------------------------------------Draw Functions----------------------------------------*/
void DrawPie(sf::RenderWindow& wn, List& Ratio, int Amount, string& Scale, bool Explode)
{
    float Sum = 0;
    for (int i=0; i<Amount; i++)
        Sum+=Ratio[i]->value;
    selbaward::PieChart pieChart;
    pieChart.slices.resize(Amount);
    float Pie_Red_Start =0, Pie_Green_Start =0, Pie_Blue_Start =0;
    Choose_Color(Pie_Red_Start, Pie_Green_Start, Pie_Blue_Start, Scale);
    float Pie_Red_Gap =255-Pie_Red_Start;
    float Pie_Green_Gap =255-Pie_Green_Start;
    float Pie_Blue_Gap =255-Pie_Blue_Start;
    for(int i=0; i<Amount; i++)
    {
        pieChart.slices[i].color = sf::Color(Pie_Red_Start, Pie_Green_Start, Pie_Blue_Start);
        Pie_Red_Start += Pie_Red_Gap*Ratio[i]->value/Sum;
        Pie_Blue_Start += Pie_Blue_Gap*Ratio[i]->value/Sum;
        Pie_Green_Start += Pie_Green_Gap*Ratio[i]->value/Sum;
        pieChart.slices[i].size = Ratio[i]->value/Sum;
        if(Explode)
            pieChart.slices[i].explode = 0.15f;
    }
    
    pieChart.setSize({ 350.f, 350.f });
    pieChart.update();
    pieChart.setOrigin(pieChart.getSize() / 2.f);
    pieChart.setPosition({ 500.f, 550.f });
    wn.draw(pieChart);
    
    //Draw buttons
    int Button_amount=3;
    sf::RectangleShape* rectangle = new sf::RectangleShape[Button_amount];
    //0: week, 1: month, 2: Year
    if(Scale=="W")
    {
        rectangle[0].setFillColor(sf::Color(26, 113, 195));
        rectangle[1].setFillColor(sf::Color(220, 239, 248));
        rectangle[2].setFillColor(sf::Color(220, 239, 248));
    }
    else if(Scale=="M")
    {
        rectangle[1].setFillColor(sf::Color(26, 113, 195));
        rectangle[0].setFillColor(sf::Color(220, 239, 248));
        rectangle[2].setFillColor(sf::Color(220, 239, 248));
    }
    else if(Scale=="Y")
    {
        rectangle[2].setFillColor(sf::Color(26, 113, 195));
        rectangle[0].setFillColor(sf::Color(220, 239, 248));
        rectangle[1].setFillColor(sf::Color(220, 239, 248));
    }
    
    rectangle[0].setPosition(Pge3_toPx(2.65), Pge3_toPx(9));
    rectangle[1].setPosition(Pge3_toPx(2.65), Pge3_toPx(10.8));
    rectangle[2].setPosition(Pge3_toPx(2.65), Pge3_toPx(12.7));
    for(int i=0; i<Button_amount; i++)
        rectangle[i].setSize(sf::Vector2f(Button_x_Gap, Button_y_Gap));
    
    sf::Text* Summarize = new sf::Text[Button_amount];
    
    float spacing = 5;
    for(int i=0; i<Button_amount; i++)
    {
        Summarize[i].setFont(font);
        Summarize[i].setCharacterSize(font_resize(18));
        if(i==0)
        {
            if(Scale=="W")
                Summarize[i].setFillColor(sf::Color::White);
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Week");
            sf::Vector2f P =  rectangle[i].getPosition();
            Summarize[i].setPosition(P.x+spacing, P.y+spacing);
        }
        else if(i==1)
        {
            if(Scale=="M")
                Summarize[i].setFillColor(sf::Color::White);
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Month");
            sf::Vector2f P =  rectangle[i].getPosition();
            Summarize[i].setPosition(P.x+spacing, P.y+spacing);
        }
        else
        {
            if(Scale=="Y")
                Summarize[i].setFillColor(sf::Color::White);
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Year");
            sf::Vector2f P =  rectangle[i].getPosition();
            Summarize[i].setPosition(P.x+spacing, P.y+spacing);
            
        }
    }
    for(int i=0; i<Button_amount; i++)
        wn.draw(rectangle[i]);
    
    for(int i=0; i<Button_amount; i++)
        wn.draw(Summarize[i]);
    delete [] Summarize;
    delete [] rectangle;
}


void DrawBar(sf::RenderWindow& wn, List& Ratio, int Amount, const string& Scale)
{
    float Sum = 0;
    for (int i=0; i<Amount; i++)
    {
        Sum+=Ratio[i]->value;
    }
    float Bar_Pos_X_Start = 0,Bar_Pos_X_End =0, Bar_Pos_X_Gap = 0, Bar_Pos_Y = 0;
    float Bar_Red_Start = 0, Bar_Green_Start = 0, Bar_Blue_Start = 0;
    string S = Scale;
    if(Scale=="W")
    {
        Bar_Pos_X_Start = ::Bar_Week_Pos_X_Start;
        Bar_Pos_X_End = ::Bar_Week_Pos_X_End;
        Bar_Pos_X_Gap = ::Bar_Week_Pos_X_Gap;
        Bar_Pos_Y = ::Bar_Week_Pos_Y;
    }
    else if(Scale=="M")
    {
        Bar_Pos_X_Start = ::Bar_Month_Pos_X_Start;
        Bar_Pos_X_End = ::Bar_Month_Pos_X_End;
        Bar_Pos_X_Gap = ::Bar_Month_Pos_X_Gap;
        Bar_Pos_Y = ::Bar_Month_Pos_Y;
    }
    else if(Scale=="Y")
    {
        Bar_Pos_X_Start = ::Bar_Year_Pos_X_Start;
        Bar_Pos_X_End = ::Bar_Year_Pos_X_End;
        Bar_Pos_X_Gap = ::Bar_Year_Pos_X_Gap;
        Bar_Pos_Y = ::Bar_Year_Pos_Y;
    }
    Choose_Color(Bar_Red_Start, Bar_Green_Start, Bar_Blue_Start, S);
    float Bar_Red_Gap = 255-Bar_Red_Start, Bar_Green_Gap = 255-Bar_Green_Start, Bar_Blue_Gap = 255-Bar_Blue_Start;
    
    //Only
    int Amount_C=Amount;
    if(Amount>5)
        Amount_C=6;
    int Count=0;
    sf::RectangleShape LineSet[Amount];
//    cout<<"Amount "<<Amount<<endl;
    while(Count<Amount_C)
    {
        if(Count==5)
        {
            float sum =0;
            for(int i=Count; i<Amount; i++)
            {
                cout<<"i "<<i<<endl;
                sum+= Ratio[Count]->value;
            }
            cout<<"sum/Sum; "<<sum/Sum;
            Bar_Pos_X_End = Bar_Pos_X_Start + Bar_Pos_X_Gap * sum/Sum;
        }
        else
            Bar_Pos_X_End = Bar_Pos_X_Start + Bar_Pos_X_Gap * Ratio[Count]->value/Sum;

        LineSet[Count].setPosition(Bar_Pos_X_Start, Bar_Pos_Y-20);
        LineSet[Count].setSize(sf::Vector2f(Bar_Pos_X_End-Bar_Pos_X_Start, ::thickness));
        LineSet[Count].setFillColor(sf::Color(Bar_Red_Start,Bar_Green_Start,Bar_Blue_Start));
        LineSet[Count].setOutlineThickness(3.f);
        LineSet[Count].setOutlineColor(sf::Color(170,170,170));

//        LineSet[Count] = *new selbaward::Line({ Bar_Pos_X_Start, Bar_Pos_Y }, { Bar_Pos_X_End, Bar_Pos_Y }, ::thickness, sf::Color(Bar_Red_Start,Bar_Green_Start,Bar_Blue_Start));
        Bar_Pos_X_Start = Bar_Pos_X_End;
        
        Bar_Red_Start+=Bar_Red_Gap*Ratio[Count]->value/Sum;
        Bar_Green_Start+=Bar_Green_Gap*Ratio[Count]->value/Sum;
        Bar_Blue_Start+=Bar_Blue_Gap*Ratio[Count]->value/Sum;
        Count++;
    }
    for(int i=0; i<Amount; i++)
        wn.draw(LineSet[i]);
}
void DrawBarTitle(sf::RenderWindow& wn)
{
    int Title_number=4;
    sf::Text* Time_Spent_Title = new sf::Text[Title_number];
    //0: Time Spent
    //1: "Week (2018.01.21 – 2018. 01.27)"
    //2: "Month (2018.01)"
    //3: "Year (2018)"
    for(int i=0; i<Title_number; i++)
    {
        Time_Spent_Title[i].setFont(font);
        if(i==0)
            Time_Spent_Title[i].setCharacterSize(font_resize(20));
        else
            Time_Spent_Title[i].setCharacterSize(font_resize(18));
        
        Time_Spent_Title[i].setFillColor(sf::Color(162, 219, 214));
        Time_Spent_Title[i].setStyle(sf::Text::Bold);
        
        if (i==0)
        {
            Time_Spent_Title[i].setString("T i m e   S p e n t");
            Time_Spent_Title[i].setPosition({240,400});
        }
        else if(i==1)
        {
            Time_Spent_Title[i].setString("W e e k");
            Time_Spent_Title[i].setPosition({240,465});
        }
        else if (i==2)
        {
            Time_Spent_Title[i].setString("M o n t h");
            Time_Spent_Title[i].setPosition({240,580});
        }
        else if (i==3)
        {
            Time_Spent_Title[i].setString("Y e a r");
            Time_Spent_Title[i].setPosition({240,700});
        }
    }
    for(int i=0; i<Title_number; i++)
        wn.draw(Time_Spent_Title[i]);
    delete [] Time_Spent_Title;
}


/*----------------------------------------Draw Week Efficiency Bar----------------------------------------*/
void DrawRBar(sf::RenderWindow& wn, MissionBag& MBag, string& Scale)
{
    float Day_Done_Amount[7]={0};
    float Day_NotDone_Amount[7]={0};
    float Week_Done_Amount[4]={0};
    float Week_NotDone_Amount[4]={0};
    float Month_Done_Amount=0;
    float Month_NotDone_Amount=0;
    
    for(int i=0; i<MBag.Bag.get_itemCount(); i++)
    {
        if(MBag.Bag[i]->GetMisDone())
        {
            if(isPast7Days(MBag.Bag[i]))
            {
                if(getWhichDay(MBag.Bag[i])!=-1)
                    Day_Done_Amount[getWhichDay(MBag.Bag[i])]++;
            }
            if(isPast4Weeks(MBag.Bag[i]))
            {
                if(getWhichWeek(MBag.Bag[i])!=-1)
                    Week_Done_Amount[getWhichWeek(MBag.Bag[i])]++;
            }
            if(isThisMonth(MBag.Bag[i]))
                Month_Done_Amount++;
        }
        else if(!MBag.Bag[i]->GetMisDone())
        {
            if(isPast7Days(MBag.Bag[i]))
            {
                if(getWhichDay(MBag.Bag[i])!=-1)
                    Day_NotDone_Amount[getWhichDay(MBag.Bag[i])]++;
            }
            if(isPast4Weeks(MBag.Bag[i]))
            {
                if(getWhichWeek(MBag.Bag[i])!=-1)
                {
                    Week_NotDone_Amount[getWhichWeek(MBag.Bag[i])]++;
                }
            }
            if(isThisMonth(MBag.Bag[i]))
                Month_NotDone_Amount++;
        }
    }
    
    if(Scale=="D")
    {
        NOW.Current();
        //Draw date
        int start_month = NOW.getMonth();
        int start_date = NOW.getDay();
        string month ;
        string date ;
        string dateToShow;
        int x_pos = 1520-Pge3_toPx(1.45);
        for(int i = 0 ; i < 7 ; i++)
        {
            sf::Text textToShow;
            textToShow.setFont(font);
            
            if(start_month <= 9)
            {
                month = '0'+to_string(start_month);
            }
            else
            {
                month = to_string(start_month);
            }
            
            if(start_date <= 9)
            {
                date = '0'+to_string(start_date);
            }
            else
            {
                date = to_string(start_date);
            }
            
            dateToShow = month+'.'+date;
            
            textToShow.setString(dateToShow);
            textToShow.setFillColor(sf::Color(255, 255, 255));
            textToShow.setCharacterSize(font_resize(13));
            textToShow.setPosition(x_pos, Pge3_toPx(16.34));
            
            wn.draw(textToShow);
            x_pos -= Pge3_toPx(1.5);
            if(start_month==1||start_month==3||start_month==5||start_month==7||start_month==8||start_month==10||start_month==12)
            {
                if(start_date == 1)
                {
                    start_date = 31;
                    start_month--;
                }
                else
                {
                    start_date--;
                }
            }
            else if(start_month==3)
            {
                if(start_date == 1)
                {
                    start_date = 28;
                    start_month--;
                }
                else
                {
                    start_date--;
                }
            }
            else
            {
                if(start_date == 1)
                {
                    start_date = 30;
                    start_month--;
                }
                else
                {
                    start_date--;
                }
            }
        }
        //Draw Bars
        float Ratio[7] = {1,1,1,1,1,1,1};
        for(int i=0; i<7; i++)
            Ratio[i] = Day_Done_Amount[i]/(Day_Done_Amount[i]+Day_NotDone_Amount[i]);
        
        //Draw Bar
        int bar_x_pos = Pge3_toPx(21.5), bar_y_pos = Pge3_toPx(16.22);
        for(int i = 0 ; i < 7 ; i++)
        {
            float height = Pge3_toPx(11.24)*(Ratio[i]);
            sf::RectangleShape bar(sf::Vector2f(Pge3_toPx(0.94), height));
            bar.setPosition(bar_x_pos, bar_y_pos-height);
            bar.setFillColor(sf::Color(162, 219, 214));
            wn.draw(bar);
            bar_x_pos += Pge3_toPx(1.5);
        }
    }
    
    else if(Scale=="W")
    {
        OurTime Default("201807080000");
        NOW.Current();
        //Draw date
        int start_month = NOW.getMonth();
        int start_date = NOW.getDay();
        int start_year = NOW.getYear();
        int Minu_Gap = NOW-Default;
        int Day_Gap = round(Minu_Gap);
        int Week_Day = Day_Gap%7;
        if(Week_Day==0)
            Week_Day=7;
//        cout<<"Minu_Gap "<<Minu_Gap<<endl;
//        cout<<"Day_Gap "<<Day_Gap<<endl;
//
//        cout<<"Week_Day "<<Week_Day<<endl;
        start_date -= (Week_Day-1);
//        cout<<"start_date "<<start_date<<endl;
        if(start_date<0)
        {
            if(start_month==1)
                start_month =12;
            else
                start_month--;
            
            if(start_month==1||start_month==3||start_month==5||start_month==7||start_month==8||start_month==10||start_month==12)
                start_date+=31;
            else if (start_month==2 && (start_year%4==0))
                start_month+=29;
            else if (start_month==2 && (start_year%4!=0))
                start_month+=28;
            else
                start_month+=30;
        }
        
        string month ;
        string date ;
        string dateToShow;
        int x_pos = Pge3_toPx(29.4);
        for(int i = 0 ; i < 4 ; i++)
        {
            sf::Text textToShow;
            textToShow.setFont(font);
            
            if(start_month <= 9)
            {
                month = '0'+to_string(start_month);
            }
            else
            {
                month = to_string(start_month);
            }
            
            if(start_date <= 9)
            {
                date = '0'+to_string(start_date);
            }
            else
            {
                date = to_string(start_date);
            }
            
            dateToShow = month+'.'+date;
            
            textToShow.setString(dateToShow);
            textToShow.setFillColor(sf::Color(255, 255, 255));
            textToShow.setCharacterSize(font_resize(13));
            textToShow.setPosition(x_pos, Pge3_toPx(16.34));
            
            wn.draw(textToShow);
            x_pos -= Pge3_toPx(2.49);
            start_date-=7;
//            cout<<"start_date "<<start_date<<endl;
            if(start_date<0)
            {
                if(start_month==1)
                {
                    start_month =12;
                }
                else
                {
                    start_month--;
                }
//                cout<<"start_month "<<start_month<<endl;
                
                if(start_month==1||start_month==3||start_month==5||start_month==7||start_month==8||start_month==10||start_month==12)
                {
                    start_date+=31;
                }
                else if (start_month==2 && (start_year%4==0))
                {
                    start_date+=29;
                }
                else if (start_month==2 && (start_year%4!=0))
                {
                    start_date+=28;
                }
                else if(start_month==4||start_month==6||start_month==9||start_month==11)
                    start_date+=30;
            }
        }
        
        
        
        
        //Draw Bars
        float Ratio[4] = {1,1,1,1};
        for(int i=0; i<4; i++)
            Ratio[i] = Week_Done_Amount[i]/(Week_Done_Amount[i]+Week_NotDone_Amount[i]);
        
        //Draw Bar
        int bar_x_pos = Pge3_toPx(21.5), bar_y_pos = Pge3_toPx(16.22);
        for(int i = 0 ; i < 4 ; i++)
        {
//            cout<<Ratio[i]<<endl;
            float height = Pge3_toPx(11.24)*(Ratio[i]);
            sf::RectangleShape bar(sf::Vector2f(Pge3_toPx(1.88), height));
            bar.setPosition(bar_x_pos, bar_y_pos-height);
            bar.setFillColor(sf::Color(162, 219, 214));
            wn.draw(bar);
            bar_x_pos += Pge3_toPx(2.5);
        }
    }
    
    
    //Draw Big completeness number
    sf::Text number;
    number.setFont(font);
    float MonthPercentage = Month_Done_Amount/(Month_Done_Amount+Month_NotDone_Amount);
//    cout<<"MonthPercentage "<<MonthPercentage<<endl;
    string percentage = to_string(MonthPercentage*100);
    percentage = percentage.substr(0,percentage.find(".")+2);
    number.setString(percentage+" %");
    number.setFillColor(sf::Color::White);
    number.setCharacterSize(font_resize(72));
    number.setPosition(Pge3_toPx(7.5), Pge3_toPx(3.37));
    number.setStyle(sf::Text::Bold);
    wn.draw(number);
}


/*----------------------------------------DRAW STATIC----------------------------------------*/
void DrawStatic(sf::RenderWindow& wn, int ChartType, string& RBar_Scale)
{
    //Draw Axis
    sf::RectangleShape y_axis(sf::Vector2f(Pge3_toPx(11.24), Pge3_toPx(0.04)));
    y_axis.rotate(90);
    y_axis.setPosition(Pge3_toPx(20.81),Pge3_toPx(4.97));
    y_axis.setFillColor(sf::Color(162, 219, 214));
    sf::RectangleShape x_axis(sf::Vector2f(Pge3_toPx(11.24), Pge3_toPx(0.04)));
    x_axis.setPosition(Pge3_toPx(20.78), Pge3_toPx(16.22));
    x_axis.setFillColor(sf::Color(162, 219, 214));
    wn.draw(y_axis);
    wn.draw(x_axis);
    
    //Draw Text
    
    sf::Text text1;
    text1.setFont(font);
    text1.setString("S u m m a r i z e d  C o m p l e t e n e s s");
    text1.setFillColor(sf::Color(162, 219, 214));
    text1.setCharacterSize(font_resize(20));
    text1.setPosition(Pge3_toPx(20), Pge3_toPx(1.87));
    text1.setStyle(sf::Text::Bold);
    wn.draw(text1);
    
    sf::Text text2;
    text2.setFont(font);
    text2.setString("T h i s  M o n t h  C o m p l e t e n e s s");
    text2.setFillColor(sf::Color(162, 219, 214));
    text2.setCharacterSize(font_resize(20));
    text2.setPosition(Pge3_toPx(5), Pge3_toPx(1.87));
    text2.setStyle(sf::Text::Bold);
    wn.draw(text2);
    
    sf::Text zero, fifty, hundred;
    zero.setFont(font);
    zero.setString("  0%");
    zero.setFillColor(sf::Color(255, 255, 255));
    zero.setCharacterSize(font_resize(20));
    zero.setPosition(Pge3_toPx(19.00), Pge3_toPx(15.6));
    wn.draw(zero);
    
    fifty.setFont(font);
    fifty.setString("50%");
    fifty.setFillColor(sf::Color(255, 255, 255));
    fifty.setCharacterSize(font_resize(20));
    fifty.setPosition(Pge3_toPx(19.00), Pge3_toPx(10.17));
    wn.draw(fifty);
    
    hundred.setFont(font);
    hundred.setString("100%");
    hundred.setFillColor(sf::Color(255, 255, 255));
    hundred.setCharacterSize(font_resize(20));
    hundred.setPosition(Pge3_toPx(19.00), Pge3_toPx(4.57));
    wn.draw(hundred);
    
    //Draw L, R Bar buttons
    int Button_amount=4;
    sf::RectangleShape* rectangle = new sf::RectangleShape[Button_amount];
    //0: Bar Chart, 1: Pie Chart, 2: 7 days, 3: 4 weeks
    if(ChartType==0)
    {
        rectangle[0].setFillColor(sf::Color(26, 113, 195));
        rectangle[1].setFillColor(sf::Color(220, 239, 248));
    }
    else if(ChartType==1)
    {
        rectangle[1].setFillColor(sf::Color(26, 113, 195));
        rectangle[0].setFillColor(sf::Color(220, 239, 248));
    }
    if(RBar_Scale=="D")
    {
        rectangle[2].setFillColor(sf::Color(26, 113, 195));
        rectangle[3].setFillColor(sf::Color(220, 239, 248));
    }
    else if(RBar_Scale=="W")
    {
        rectangle[3].setFillColor(sf::Color(26, 113, 195));
        rectangle[2].setFillColor(sf::Color(220, 239, 248));
    }
    
    rectangle[0].setPosition(Button_x_Start, Button_y_Start);
    rectangle[1].setPosition(Button_x_End, Button_y_Start);
    rectangle[2].setPosition(Pge3_toPx(22.6), Button_y_Start);
    rectangle[3].setPosition(Pge3_toPx(26.1), Button_y_Start);
    
    rectangle[0].setSize(sf::Vector2f(Button_x_Gap, Button_y_Gap));
    rectangle[1].setSize(sf::Vector2f(Button_x_Gap, Button_y_Gap));
    rectangle[2].setSize(sf::Vector2f(Pge3_toPx(3.3), Pge3_toPx(0.96)));
    rectangle[3].setSize(sf::Vector2f(Pge3_toPx(3.7), Pge3_toPx(0.96)));
    
    //FILL IN THE TEXTES ONLY TOP 5
    sf::Text* Summarize = new sf::Text[Button_amount];
    float spacing = 1;
    float Font_x_pos = Button_x_Start+spacing, Font_y_pos = Button_y_Start+spacing;
    for(int i=0; i<Button_amount; i++)
    {
        Summarize[i].setFont(font);
        Summarize[i].setCharacterSize(font_resize(18));
        if(i==0)
        {
            if(ChartType==0)
                Summarize[i].setFillColor(sf::Color(220, 239, 248));
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Bar Chart");
            Summarize[i].setPosition({Font_x_pos, Font_y_pos});
            Font_x_pos = Button_x_End+spacing+1;
            Font_y_pos = Button_y_Start+spacing;
        }
        else if(i==1)
        {
            if(ChartType==0)
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            else
                Summarize[i].setFillColor(sf::Color(220, 239, 248));
            Summarize[i].setString("Pie Chart");
            Summarize[i].setPosition({Font_x_pos, Font_y_pos});
        }
        else if(i==2)
        {
            if(RBar_Scale=="D")
                Summarize[i].setFillColor(sf::Color(220, 239, 248));
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Past 7 Days");
            Summarize[i].setPosition(Pge3_toPx(22.6)+spacing*4, Button_y_Start+spacing);
        }
        else if(i==3)
        {
            if(RBar_Scale=="W")
                Summarize[i].setFillColor(sf::Color(220, 239, 248));
            else
                Summarize[i].setFillColor(sf::Color(26, 113, 195));
            Summarize[i].setString("Past 4 Weeks");
            Summarize[i].setPosition(Pge3_toPx(26.1)+spacing*4, Button_y_Start+spacing);
        }
    }
    for(int i=0; i<Button_amount; i++)
        wn.draw(rectangle[i]);
    
    for(int i=0; i<Button_amount; i++)
        wn.draw(Summarize[i]);
    delete [] Summarize;
    delete [] rectangle;
}



/*------------------------------------------------------PAGE 3-------------------------------------------------------------------*/





/*------------------------------------------------------PAGE 2-------------------------------------------------------------------*/

float toPx(float cm)
{
    return cm*(1600/28.6);
}
float Pge3_toPx(float cm)
{
    return cm*(991/20.81);
}
float inCM(float length)
{
    return 1600 * length / 33.867;
}
float inPT(float length)
{
    return inCM(length * 0.03527);
}
float font_resize(int oriSize)
{
    return 1.7 * static_cast<float>(oriSize);
}


int round(int MinuGap)
{
    int week  =MinuGap/1440;
    if(MinuGap%1440 !=0)
        week++;
    if(week==0)
        return week;
    return week-1;
}

int OutTimeHM2Int(OurTime& T)
{
    int SUM=0;
    SUM+=T.getMinute()+T.getHour()*60;
    return SUM;
}

void DrawCalenderBox(sf::RenderWindow& wn, sf::RectangleShape*ALL_RECTAN, const MissionBag& MBag, const FixedEventBag& FEBag, int move)
{
    OurTime Default("201807080000");
    NOW.Current();
    
    int Now_MinuGap = NOW - Default;
    int Now_DayGap = round(Now_MinuGap);
    
    int Now_Week_Day = (Now_DayGap)%7;
    OurTime Start = CountDate(NOW, Now_Week_Day);//start date of this week
    OurTime End =  CountDate(NOW, Now_Week_Day-6);//end date of this week
    End.setHour(23);
    End.setMinute(59);
    if(move<0)
    {
        int count = abs(move);
        while(count>0)
        {
            Start = CountDate(Start, 7);
            End = CountDate(End, 7);
            count--;
        }
    }
    else if(move>0)
    {
        int count = abs(move);
        while(count>0)
        {
            Start = CountDate(Start, -7);
            End = CountDate(End, -7);
            count--;
        }
    }
    
    for(int i=0; i<MBag.Bag.getSize(); i++)
    {
        OurTime MStartTime;
        OurTime MEndTime;
        
        string MName;
        
        MStartTime  =  MBag.Bag[i]->getStartTime();
        MEndTime =  MBag.Bag[i]->GetendTime();
        MName = MBag.Bag[i]->GetName();
        
        //Draw Missions
        if(Start<=MStartTime && End>=MStartTime)
        {
            int M_MinuGap = MStartTime - Default;
            int M_DayGap = round(M_MinuGap);
            if(MStartTime.getHour()==0 && MStartTime.getMinute()==0)
                M_DayGap +=1;
            int M_Week_Day = (M_DayGap)%7;
            X_Start = X_Metrix[M_Week_Day];
            Y_Start = Y_Origin+OutTimeHM2Int(MStartTime)*Y_Width_perMin;
            Y_Length =Y_Width_perMin*(MEndTime-MStartTime);
            
            //Draw Boxes
            if(!MBag.Bag[i]->GetMisDone())
                ALL_RECTAN[i].setFillColor(sf::Color(90, 175, 190, 250.0));
            else
                ALL_RECTAN[i].setFillColor(sf::Color(36, 86, 94, 250.0));
            
            ALL_RECTAN[i].setOutlineColor(sf::Color(0, 0, 0, 250.0));
            ALL_RECTAN[i].setOutlineThickness(2.f);
            
            
            ALL_RECTAN[i].setPosition(X_Start, Y_Start);
            ALL_RECTAN[i].setSize(sf::Vector2f(X_Length, Y_Length));
            wn.draw(ALL_RECTAN[i]);
            
            sf::Text text;
            text.setFont(font);
            text.setCharacterSize(font_resize(14));
            text.setFillColor(sf::Color(255, 255, 255));
            text.setString(MName);
            float offset_x = text.getLocalBounds().width;
            float offset_y = text.getLocalBounds().height;
            
            
            text.setPosition(X_Start+(X_Length-offset_x)/2, Y_Start+(Y_Length-offset_y-10)/2);
            if((MEndTime-MStartTime)>=60)
                wn.draw(text);
        }
        
    }
    for(int i=0; i<FEBag.Bag.getSize(); i++)
    {
        
        OurTime FEStartTime;
        OurTime FEEndTime;
        string FEName;
        
        FEStartTime  =  FEBag.Bag[i]->getStartTime();
        FEEndTime =  FEBag.Bag[i]->GetendTime();
        FEName = FEBag.Bag[i]->GetName();
        
        //Draw FixedEvent
        if(Start<=FEStartTime && End>=FEStartTime)
        {
            
            int FE_MinuGap = FEStartTime - Default;
            int FE_DayGap = round(FE_MinuGap);
            if(FEStartTime.getHour()==0 && FEStartTime.getMinute()==0)
                FE_DayGap +=1;
            int FE_Week_Day = (FE_DayGap)%7;
            
            
            X_Start = X_Metrix[FE_Week_Day];
            Y_Start = Y_Origin+OutTimeHM2Int(FEStartTime)*Y_Width_perMin;
            Y_Length =Y_Width_perMin*(FEEndTime-FEStartTime);

            //Draw Boxes
            ALL_RECTAN[i+MBag.Bag.getSize()].setFillColor(sf::Color(162, 219, 214));
            ALL_RECTAN[i+MBag.Bag.getSize()].setOutlineColor(sf::Color(0, 0, 0, 250.0));
            ALL_RECTAN[i+MBag.Bag.getSize()].setOutlineThickness(2.f);
            
            ALL_RECTAN[i+MBag.Bag.getSize()].setPosition(X_Start, Y_Start);
            ALL_RECTAN[i+MBag.Bag.getSize()].setSize(sf::Vector2f(X_Length, Y_Length));
            wn.draw(ALL_RECTAN[i+MBag.Bag.getSize()]);
            
            sf::Text text;
            text.setFont(font);
            text.setCharacterSize(font_resize(14));
            text.setFillColor(sf::Color(66, 149, 163, 250.0));
            text.setString(FEName);
            float offset_x = text.getLocalBounds().width;
            float offset_y = text.getLocalBounds().height;
            
            text.setPosition(X_Start+(X_Length-offset_x)/2, Y_Start+(Y_Length-offset_y-10)/2);
            if((FEEndTime-FEStartTime) >=60)
                wn.draw(text);
        }
    }
    //Date
    sf::Text date[7];
    OurTime Itorator = Start;
    for(int i = 0; i < 7; i++)
    {
        string Day = to_string(Itorator.getDay());
        if(Day.length()==1)
            Day.insert(0,"0");
        Day+=" ";
        date[i].setFont(font);
        date[i].setCharacterSize(font_resize(18));
        date[i].setFillColor(sf::Color(255, 255, 255));
        date[i].setPosition(inCM(8.05 + 3.24 * i), inCM(2.76));
        switch(i)
        {
            case 0:
                date[i].setString(Day +std::string("Sun."));
                break;
            case 1:
                date[i].setString(Day + std::string("Mon."));
                break;
            case 2:
                date[i].setString(Day + std::string("Tues."));
                break;
            case 3:
                date[i].setString(Day + std::string("Wed."));
                break;
            case 4:
                date[i].setString(Day + std::string("Thu."));
                break;
            case 5:
                date[i].setString(Day + std::string("Fri."));
                break;
            case 6:
                date[i].setString(Day + std::string("Sat."));
                break;
        }
        Itorator = CountDate(Itorator, -1);
    }
    
    for(int i = 0; i < 7; i++) //date text
        wn.draw(date[i]);
    
    //Title(2018 January)
    string Year = to_string(Start.getYear());
    int Month =  Start.getMonth();
    sf::Text title;
    title.setFont(font);
    string Title_S = Year.substr(0,1)+"    "+Year.substr(1,1)+"    "+Year.substr(2,1)+"    "+Year.substr(3,1)+"        ";
    if(Month==1)
        Title_S+="J    A    N    U    A    R    Y";
    else if(Month==2)
        Title_S+="F    A    B    U    A    R    Y";
    else if(Month==3)
        Title_S+="M    A    R    C    H";
    else if(Month==4)
        Title_S+="A    P    R    I    L";
    else if(Month==5)
        Title_S+="M    A    Y";
    else if(Month==6)
        Title_S+="J    U    N    E";
    else if(Month==7)
        Title_S+="J    U    L    Y";
    else if(Month==8)
        Title_S+="A    U    G    U    S    T";
    else if(Month==9)
        Title_S+="S    E    P    T    E    M    B    E    R";
    else if(Month==10)
        Title_S+="O    C    T    O    B    E    R";
    else if(Month==11)
        Title_S+="N    O    V    E    M    B    E    R";
    else if(Month==12)
        Title_S+="D    E    C    E    M    B    E    R";
    
    title.setString(Title_S);
    title.setCharacterSize(font_resize(20));
    title.setStyle(sf::Text::Bold);
    title.setFillColor(sf::Color(86, 175, 191));
    title.setPosition(800 + inCM(1.5) - title.getLocalBounds().width / 2, inCM(1.14));
    wn.draw(title);
    
    //    //Vertical lines
    //    sf::RectangleShape v_linePtr[8];
    //    for(int i = 0; i < 8; i++)
    //    {
    //        v_linePtr[i].setSize(sf::Vector2f(inPT(0.5), inCM(15)));
    //        v_linePtr[i].setFillColor(sf::Color(65, 154, 169));
    //        v_linePtr[i].setPosition(inCM(7.36 + 3.24 * i), inCM(2.76));
    //    }
    //
    //    for(int i = 0; i < 8; i++) //vertical line
    //        wn.draw(v_linePtr[i]);
    
}

OurTime CountDate(OurTime& TIME, int Gap)
{
    //Draw date
    int start_year = TIME.getYear();
    int start_month  = TIME.getMonth();
    int start_date  = TIME.getDay();
    
    start_date-=Gap;
    if(start_date<0)
    {
        if(start_month==1)
        {
            start_year--;
            start_month =12;
        }
        else
            start_month--;
        
        if(start_month==1||start_month==3||start_month==5||start_month==7||start_month==8||start_month==10||start_month==12)
            start_date+=31;
        else if (start_month==2 && (start_year%4==0))
            start_date+=29;
        else if (start_month==2 && (start_year%4!=0))
            start_date+=28;
        else if(start_month==4||start_month==6||start_month==9||start_month==11)
            start_date+=30;
    }
    
    if(start_date>28)
    {
        if(start_month==2 && (start_year%4!=0))
        {
            if(start_date>28)
            {
                start_date-=28;
                start_month++;
            }
        }
        else if(start_month==2 && (start_year%4==0))
        {
            if(start_date>29)
            {
                start_date-=29;
                start_month++;
            }
        }
        else if(start_month==12)
        {
            if(start_date>31)
            {
                start_date-=31;
                start_month =1 ;
                start_year++;
            }
        }
        else if(start_month==1||start_month==3||start_month==5||start_month==7||start_month==8||start_month==10)
        {
            if(start_date>31)
            {
                start_date-=31;
                start_month++;
            }
        }
        else if(start_month==4||start_month==6||start_month==9||start_month==11)
        {
            if(start_date>30)
            {
                start_date-=30;
                start_month++;
            }
        }
    }
    string year = to_string(start_year);
    string month = to_string(start_month);
    if(month.length()==1)
        month.insert(0,"0");
    string day = to_string(start_date);
    if(day.length()==1)
        day.insert(0,"0");
    string hour =to_string(0);
    if(hour.length()==1)
        hour.insert(0,"0");
    string min = to_string(0);
    if(min.length()==1)
        min.insert(0,"0");
    string s = year+month+day+hour+min;
    OurTime RESULT(s);
    return RESULT;
}

int MouseOnBoxes(sf::RenderWindow& wn, sf::RectangleShape* RS, int total)
{
    float Mx = sf::Mouse::getPosition(wn).x;
    float My = sf::Mouse::getPosition(wn).y;
    int index=-1;
    for(int i=0; i<total; i++)
    {
        sf::Vector2f Pos = RS[i].getPosition();
        sf::Vector2f Leng = RS[i].getSize();
        if(Mx>=Pos.x && Mx<=Pos.x+Leng.x && My >=Pos.y && My<= Pos.y+Leng.y)
        {
            index = i;
            break;
        }
    }
    return index;
}

int MouseOnTurnPage(sf::RenderWindow& wn, sf::CircleShape& leftButton, sf::CircleShape& rightButton)
{
    float Mx = sf::Mouse::getPosition(wn).x;
    float My = sf::Mouse::getPosition(wn).y;
    sf::Vector2f LPos= {110.,440.};
    float Lsiz= 30;
    sf::Vector2f RPos= {1520.,430.};
    float Rsiz=  30;
    
    if(Mx>=LPos.x && Mx<=LPos.x+Lsiz && My >=LPos.y && My<= LPos.y+Lsiz)
        return -1;
    else if(Mx>=RPos.x && Mx<=RPos.x+Rsiz && My >=RPos.y && My<= RPos.y+Rsiz)
        return 1;
    return 0;
}


void DrawBoxMes(sf::RenderWindow& wn, sf::RectangleShape* RS,sf::RectangleShape* BoxMes_Button, const MissionBag& MBag, const FixedEventBag& FEBag, int index)
{
    OurTime Default("201807080000");
    OurTime Event;
    sf::Vector2f Pos = RS[index].getPosition();
    string name;
    string StartTime;
    string EndTime;
    string TIME;
    string H_Duration;
    string M_Duration;
    bool Done=false;
    bool isM=false;
    //FixedEvent
    if(index >= MBag.Bag.getSize())
    {
        name = FEBag.Bag[index-MBag.Bag.getSize()]->GetName();
        StartTime= FEBag.Bag[index-MBag.Bag.getSize()]->GetstartTime();
        EndTime = FEBag.Bag[index-MBag.Bag.getSize()]->GetendTime();
        
        TIME += StartTime.substr(8,2)+":"+StartTime.substr(10,2)+" - ";
        TIME += EndTime.substr(8,2)+":"+EndTime.substr(10,2);
        H_Duration = to_string(FEBag.Bag[index-MBag.Bag.getSize()]->getDuration()/60);
        M_Duration = to_string(FEBag.Bag[index-MBag.Bag.getSize()]->getDuration()%60);
        Event = FEBag.Bag[index-MBag.Bag.getSize()]->getStartTime();
    }
    else
    {
        isM =true;
        name = MBag.Bag[index]->GetName();
        StartTime= MBag.Bag[index]->GetstartTime();
        EndTime = MBag.Bag[index]->GetendTime();
        
        TIME += StartTime.substr(8,2)+":"+StartTime.substr(10,2)+" - ";
        TIME += EndTime.substr(8,2)+":"+EndTime.substr(10,2);
        H_Duration = to_string(MBag.Bag[index]->getDuration()/60);
        M_Duration = to_string(MBag.Bag[index]->getDuration()%60);
        Event = MBag.Bag[index]->getStartTime();
        Done = MBag.Bag[index]->GetMisDone();
    }
    
    float Y_Mes_len = inCM(3.8);
    float X_Mes_len = toPx(4.8);
    float Y_Mes = Pos.y;
    float X_Mes;
    if( ((Event - Default)/1440)%7 ==6 )
        X_Mes = Pos.x-10-toPx(4.8);
    else
        X_Mes =  Pos.x+X_Length+10;
    if(Event.getHour() >= 20)
        Y_Mes =Pos.y-Y_Mes_len;
    
    sf::RectangleShape rectangle;
    rectangle.setFillColor(sf::Color(255, 255, 255));
    
    rectangle.setPosition(X_Mes, Y_Mes);
    rectangle.setSize(sf::Vector2f(X_Mes_len, Y_Mes_len));
    wn.draw(rectangle);
    
    
    //Name TIME Duraiton
    for(int i=0; i<3; i++)
    {
        sf::Text text;
        text.setFont(font);
        text.setFillColor(sf::Color(90, 175, 190));
        if(i==0)
        {
            text.setCharacterSize(font_resize(16));
            text.setStyle(sf::Text::Bold|sf::Text::Underlined);
            text.setString(name);
            text.setPosition(X_Mes+10, Y_Mes+10);
            Remove_Button_X = X_Mes+10;
        }
        else if(i==1)
        {
            text.setCharacterSize(font_resize(14));
            text.setString(TIME);
            text.setPosition(X_Mes+10, Y_Mes+toPx(1));
        }
        
        else if(i==2)
        {
            text.setCharacterSize(font_resize(14));
            text.setString(H_Duration+" Hour "+M_Duration+" Min");
            text.setPosition(X_Mes+10, Y_Mes+toPx(1.6));
            Remove_Button_Y = Y_Mes+toPx(1.6)+text.getLocalBounds().height+toPx(0.5);
        }
        wn.draw(text);
    }
    
    sf::Text text[2];
    
    //Remove
    
    BoxMes_Button[0].setFillColor(sf::Color(249, 109, 134));
    
    BoxMes_Button[0].setPosition(Remove_Button_X, Remove_Button_Y);
    BoxMes_Button[0].setSize(sf::Vector2f(Remove_Button_XLen, Remove_Button_YLen));
    text[0].setFont(font);
    text[0].setFillColor(sf::Color::White);
    text[0].setCharacterSize(font_resize(12));
    text[0].setString("Remove");
    text[0].setPosition(Remove_Button_X+10, Remove_Button_Y);
    
    
    if(isM)
    {
        //Check
        BoxMes_Button[1].setFillColor(sf::Color(167, 221, 216));
        
        BoxMes_Button[1].setPosition(Remove_Button_X+Remove_Button_XLen+10, Remove_Button_Y);
        BoxMes_Button[1].setSize(sf::Vector2f(Check_Button_XLen, Check_Button_YLen));
        text[1].setFont(font);
        text[1].setFillColor(sf::Color::White);
        text[1].setCharacterSize(font_resize(12));
        text[1].setString("Done");
        text[1].setPosition(Remove_Button_X+Remove_Button_XLen+30, Remove_Button_Y);
    }
    
    //Close Mes Box
    BoxMes_Button[2].setFillColor(sf::Color::White);
    
    BoxMes_Button[2].setPosition(X_Mes_len+X_Mes-toPx(0.6), Y_Mes+5);
    BoxMes_Button[2].setSize(sf::Vector2f(toPx(0.5), toPx(0.5)));
    
    wn.draw(BoxMes_Button[2]);
    
    wn.draw(BoxMes_Button[0]);
    if(isM&&!Done)
        wn.draw(BoxMes_Button[1]);
    
    sf::Text X;
    X.setFillColor(sf::Color(100,100,100));
    X.setPosition(X_Mes_len+X_Mes-toPx(0.6), Y_Mes+5);
    X.setFont(font);
    X.setCharacterSize(font_resize(18));
    X.setString("X");
    wn.draw(X);
    wn.draw(text[0]);
    wn.draw(text[1]);
}

/*------------------------------------------------------PAGE 2-------------------------------------------------------------------*/


