#include "Page3_Draw_Coefficients.hpp"
//Position
float thickness = 50, Gap=60;
//Buttons
float Button_x_Start = 380, Button_x_End = 500, Button_y_Start = 830, Button_y_End = 870;
float Button_x_Gap = Button_x_End-Button_x_Start, Button_y_Gap = Button_y_End-Button_y_Start;

//Week
float Bar_Week_Pos_X_Start = 240,Bar_Week_Pos_X_End =0, Bar_Week_Pos_X_Gap = 560, Bar_Week_Pos_Y = 530;
//Month
float Bar_Month_Pos_X_Start = 240,Bar_Month_Pos_X_End =0, Bar_Month_Pos_X_Gap = 560, Bar_Month_Pos_Y = Bar_Week_Pos_Y +2*Gap;
//Year
float Bar_Year_Pos_X_Start = 240,Bar_Year_Pos_X_End =0, Bar_Year_Pos_X_Gap = 560, Bar_Year_Pos_Y = Bar_Week_Pos_Y +4*Gap;


//Color
//Week
float Bar_Week_Red_Start = 8, Bar_Week_Green_Start = 104, Bar_Week_Blue_Start = 78;
float
Bar_Week_Red_Gap = 255-Bar_Week_Red_Start,
Bar_Week_Green_Gap = 255-Bar_Week_Green_Start,
Bar_Week_Blue_Gap = 255-Bar_Week_Blue_Start;
//Month
float Bar_Month_Red_Start = 17, Bar_Month_Green_Start = 104, Bar_Month_Blue_Start = 108;
float
Bar_Month_Red_Gap = 255-Bar_Month_Red_Start,
Bar_Month_Green_Gap = 255-Bar_Month_Green_Start,
Bar_Month_Blue_Gap = 255-Bar_Month_Blue_Start;
//Year
float Bar_Year_Red_Start = 12, Bar_Year_Green_Start = 56, Bar_Year_Blue_Start = 98;
float
Bar_Year_Red_Gap = 255-Bar_Year_Red_Start,
Bar_Year_Green_Gap = 255-Bar_Year_Green_Start,
Bar_Year_Blue_Gap = 255-Bar_Year_Blue_Start;
