#ifndef KNAPSCAK_H_INCLUDED
#define KNAPSCAK_H_INCLUDED

#include "mission.h"
#include "Bags&List.hpp"
using namespace std;

int max(int a, int b);
MissionBag* KnapSack(MissionBag &m,int weight);


#endif // KNAPSCAK_H_INCLUDED
